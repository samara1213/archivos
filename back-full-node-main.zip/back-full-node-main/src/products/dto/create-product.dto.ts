import { IsString, 
         MinLength,
         IsArray,
         IsIn,
         IsInt,
         IsNumber,
         IsOptional,
         IsPositive } from "class-validator";


export class CreateProductDto {

    @IsString()
    @MinLength(1)
    title: string;

    @IsNumber()
    @IsPositive()
    @IsOptional()
    price?: number;

    @IsString()
    @IsOptional()
    descripcion?: string;

    @IsString()
    @IsOptional()
    slug?: string;

    @IsInt()
    @IsPositive()
    @IsOptional()
    stock: number;

    // @IsString({each:true}) // lo qiue hace es decir que cada elemento debe ser string
    // @IsArray()
    // sizes: string[];

    @IsIn(['men','women','kid','unisex']) // que este dentro des des arrglo
    gender: string;

    @IsString()
    @IsOptional()
    tags?: string;

    @IsString()
    @IsOptional()
    images?: string;
}
