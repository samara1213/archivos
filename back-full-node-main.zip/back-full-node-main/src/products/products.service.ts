import { Injectable,Logger } from '@nestjs/common';
import { BadRequestException, InternalServerErrorException } from '@nestjs/common/exceptions';
import { InjectRepository } from '@nestjs/typeorm';
import { PaginationDto } from 'src/common/dtos/pagination.dto';
import { DataSource, Repository } from 'typeorm';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { Product } from './entities/product.entity';
import {validate as isUUID} from 'uuid'; // esta se utiliza para validar el uuid se intala paque yarn add uuid y yarn add - D @Types/u
import { ProductImage } from './entities/product-image.entity';
import { User } from 'src/auth/entities/user.entity';

@Injectable()
export class ProductsService {

  // para manejar los log
  private readonly logger  = new  Logger('ProductsService');

  //declaramos el constructor para inyectar el repositorio
  constructor(

    @InjectRepository(Product)
    private readonly productRepository: Repository<Product>,

    @InjectRepository(ProductImage)
    private readonly productImegeRepository: Repository<ProductImage>,
    
    private readonly dataSource: DataSource,
  ){}

  async create(createProductDto: CreateProductDto, user: User) {
    
    try {

      const {images, ...producProperties} = createProductDto
      // se crea el producto a guardar
      const product = this.productRepository.create({
        ...producProperties,
        images: this.productImegeRepository.create({url:images}),
        user,
      });

      // se guarda el producto en la base de datos
      await this.productRepository.save(product);

      return product;
    
    } catch (error) {    
      
      this.handlerExeptions(error);
      
    }

  }

  async findAll(paginationDto: PaginationDto) {
    
    try {
      
      const {limit = 10, offset = 0} = paginationDto;
      // de esta manera se paginan los resultados 
      const productos = await this.productRepository.find({
        take: limit,
        skip: offset,
        relations:{
          images: true,
        }

      });

      return productos.map(producto =>({

        ...producto,
        images: producto.images,
      }));
    } catch (error) {
      
    }
  }

  async findOne(term: string) {
   
    //deaclramos el objecto que vamos a regresar
    let product : Product;

    //validamos si es un uuid
    if (isUUID(term)){

      product = await this.productRepository.findOneBy({id:term});
    } else {

     // crear un query
     const queryBuilder = this.productRepository.createQueryBuilder('prod');

     product = await queryBuilder
              .where('title =:title or slug =:slug',{
                title : term,
                slug : term,
              })
              .leftJoinAndSelect('prod.images','prodImages')
              .getOne();
    }
    if(!product){
      throw new BadRequestException('producto no encontrado');
      
    }
    return product
  }

  async update(id: string, updateProductDto: UpdateProductDto) {
    

    // de esta forma se actualiza utilizando transacciones
    const {images, ...toUpdate} = updateProductDto;

    const producto = await this.productRepository.preload({id: id, ...toUpdate});

    if(!producto) throw new BadRequestException('El producto a actualizar no existe');


    // creamos query runner que ems el que se utiliza para transacciones
    const queryRunner = this.dataSource.createQueryRunner();

    await queryRunner.connect();
    await queryRunner.startTransaction(); 

    // se guarda la actualizacion
    try {
      
      if (images) {
        await queryRunner.manager.delete(ProductImage,{ producto: {id}});

        producto.images = this.productImegeRepository.create({url:images})
      }
      
      await queryRunner.manager.save(producto);

      await queryRunner.commitTransaction();
      await queryRunner.release();
      return producto;

    } catch (error) {
     
      console.log(error);
      await queryRunner.rollbackTransaction();
      await queryRunner.release();
      this.handlerExeptions(error);
    }
    
  }

  async remove(id: string) {
    const producto = await this.findOne(id);

    await this.productRepository.remove(producto);

  }

  private handlerExeptions(error : any){

    console.log(error);

    if(error.errno === 1062)
      throw new BadRequestException(error.sqlMessage);
    
    this.logger.error(error);
    
    throw new InternalServerErrorException('error no controlado en el metodo');
    
      
  }
}
