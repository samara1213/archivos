import { BeforeInsert, BeforeUpdate, Column, Entity, ManyToOne, OneToMany, PrimaryGeneratedColumn } from "typeorm";
import { ProductImage } from "./product-image.entity";
import { User } from "src/auth/entities/user.entity";


@Entity({name: 'products'})
export class Product {

@PrimaryGeneratedColumn('uuid')
id: string;

@Column('text',{
    unique: true,
}) // asi se le agregan reglas: que el tipo de datos sea testo y sea unico
title: string;

@Column('numeric',{
    default: 0
})
price: number;

@Column({
    type: 'text',
    nullable: true
})
descripcion: string;

@Column({
    type: 'text',
    unique: true
})
slug: string;

@Column({
    type: 'int',
    default: 0
})
stock: number;

// @Column({
//     type: 'text',
//     array: true,
//     default:[]
// })
// sizes: string[];

@Column({
    type: 'text'
})
gender: string;

// @Column({
//     type: 'text',
//     array: true,
//     default:[]
// })
// tags: string[];

@Column({
    type: 'text'
})
tags: string;

// de esta forma se hacen relaciones entre las tablas
//imagenes
@OneToMany(
    () => ProductImage,
    (productImage) => productImage.product,
    {cascade: true, eager: true} // eager: true se utiliza para que todas las relacions de la tabla se muestren 

)
images?: ProductImage;

@ManyToOne(
    () => User,
    (user) => user.product,
    {eager: true}
)
user: User

// esto se utiliza antes de insertar un registro ejecuta el metodo
@BeforeInsert()
checkSlug(){

    if(!this.slug || this.slug ===''){

        this.slug = this.title
        .toLocaleLowerCase()
        .replaceAll(' ','_')
        .replaceAll("'",'');
    } else {

        this.slug = this.slug
        .toLocaleLowerCase()
        .replaceAll(' ','_')
        .replaceAll("'",'');
    }
}

@BeforeUpdate()
checkSlugUpdate(){

    if(!this.slug || this.slug ===''){

        this.slug = this.title
        .toLocaleLowerCase()
        .replaceAll(' ','_')
        .replaceAll("'",'');
    } else {

        this.slug = this.slug
        .toLocaleLowerCase()
        .replaceAll(' ','_')
        .replaceAll("'",'');
    }
}
}
