import { Product } from 'src/products/entities/product.entity';
import { Column, Entity, PrimaryGeneratedColumn, OneToMany } from 'typeorm';


@Entity('users')
export class User {

    @PrimaryGeneratedColumn('uuid')
    id: string;

    @Column('text',{
        unique: true
    })
    email: string;

    @Column('text',{
        select: false // este se utilia para no regresar la contraseña en ninguna columna
    })
    password: string;

    @Column('text')
    fullName: string;

    @Column('boolean',{
        default: true
    })
    isActive: boolean;

    /**de esta manera se utiliza rraglo para postgres
     * @Column('text',{
     * array: true,
     * default: ['user']})
     * no se por que con mysql no funciona puede que sea la version de la db
     */
    @Column('text',{       
        default: 'user'
    })
    roles : string[];

    @OneToMany(
        () => Product,
        (product) => product.user
    )
    product: Product;

}
