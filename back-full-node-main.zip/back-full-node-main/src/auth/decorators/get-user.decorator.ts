import { ExecutionContext, InternalServerErrorException, createParamDecorator } from "@nestjs/common";

/**
 * de esta manera se crean los decoradores personalizados 
 * 
 */

export const GetUser = createParamDecorator(
    (data: string, ctx: ExecutionContext) => {

        const req = ctx.switchToHttp().getRequest();

        const user = req.user;

        if(!user)
        throw new InternalServerErrorException('Error con la autenticacion');
        
        //return user; una forma de regresar
        //otra forma es esta
        
        return (!data) ? user : user[data];
    }
    
);