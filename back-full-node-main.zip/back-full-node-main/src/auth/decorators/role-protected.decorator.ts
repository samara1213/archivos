import { SetMetadata } from '@nestjs/common';
import { ValidRole } from '../interfaces/valid-role.interfaces';

export const META_ROLE = 'roles';

export const RoleProtected = (...args: ValidRole[]) => {
    
   return SetMetadata(META_ROLE, args);

}
