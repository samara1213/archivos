import { Controller, Get, Post, Body, Patch, Param, Delete, UseGuards, Req, SetMetadata } from '@nestjs/common';
import { AuthService } from './auth.service';
import { CreateUserDto } from './dto/create-user.dto';
import { LoginUserDto } from './dto/login-user.dto';
import {AuthGuard} from '@nestjs/passport';
import { User } from './entities/user.entity';
import { RawHeadres,GetUser } from './decorators';
import { UserRoleGuard } from './guards/user-role/user-role.guard';
import { RoleProtected } from './decorators/role-protected.decorator';
import { ValidRole } from './interfaces/valid-role.interfaces';
import { Auth } from './decorators/auth.decorator';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('register')
  create(@Body() createUserDto: CreateUserDto) {
    return this.authService.create(createUserDto);
  }

  @Post('login')
  login(@Body() loginUserDto: LoginUserDto) {
    return this.authService.login(loginUserDto);
  }

  @Get('private')
  @UseGuards( AuthGuard())// estas anotaciones son para la autorizacion
  testingPrivareRoute(
    @GetUser() user: User,
    @GetUser('email') email: string,
    @RawHeadres() rawHeaders: string[]
  ){

    return 'ok';
  }

  // @SetMetadata('roles',['admin','user']) // valida los roles del usuario
  @Get('private2')
  @RoleProtected( ValidRole.admin)
  @UseGuards( AuthGuard(), UserRoleGuard)// estas anotaciones son para la autorizacion 
  testingPrivareRoute2(
    @GetUser() user: User,    
  ){

    return 'ok';
  }

  @Get('private3')
  @Auth()
  testingPrivareRoute3(
    @GetUser() user: User,    
  ){

    return 'ok';
  }

  @Get('check-status')
  checkAuthStatus(
    @GetUser() user: User,
  ){

    return this.authService.checkAuthStatus(user);
  }


}
