

export interface JwtPayload {

    id: string;

    // TODO: añadir todo lo que se quiera grabar el JWT
}