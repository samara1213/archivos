

export enum ValidRole{

    admin ='admin',
    superUser = 'super-user',
    user = 'user',

}