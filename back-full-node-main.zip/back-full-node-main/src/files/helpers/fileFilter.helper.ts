import { Request } from "express";



export const fileFilter = (req: Request, file: Express.Multer.File, cb: Function) => {


    if (!file) return cb(new Error('archivo no puede ser vacio'), false);

    const fileExtension = file.mimetype.split('/')[1];

    const ExtensionValida = ['jpg','png','git'];

    if (ExtensionValida.includes(fileExtension)){

        return cb(null,true);
    }

     cb(null, false);
    
}