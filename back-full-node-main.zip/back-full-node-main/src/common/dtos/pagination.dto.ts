import { Type } from "class-transformer";
import { IsInt, IsOptional, IsPositive, Min } from "class-validator";


export class PaginationDto {

    @IsOptional()
    @IsPositive()
    @Type(() => Number) // esto se utiliza para transformar el string a numero
    limit?: number;

    @IsOptional()
    @Min(0)
    @Type(() => Number) // esto se utiliza para transformar el string a numero
    offset?: number;
}