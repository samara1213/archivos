

export const HooksApp = () => {
  return (
    <h1>HooksApp</h1>

  )
}
