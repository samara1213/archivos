

export const AbautPage = () => {
  return (
<>
<h1>abaut</h1>
<hr />
</>
  )
}
