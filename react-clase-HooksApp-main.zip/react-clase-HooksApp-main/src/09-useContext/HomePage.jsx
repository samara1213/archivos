

export const HomePage = () => {
  return (
<>
<h1>Home</h1>
<hr />
</>
  )
}
