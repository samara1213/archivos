import { useFech } from "../hook/useFech";

export const MultiplesCustomHooks = () => {
  
    const {} = useFech('https://www.breakingbadapi.com/api/quotes/3');
  
  return (
<>
<h1>multiples hooks</h1>
<hr />

</>
  )
}
