import { createSlice } from '@reduxjs/toolkit'


export const authSlice = createSlice({
  name: 'auth',
  initialState: {
    status: 'checking', // checking, not-autenticate, autenticated
    uuid: null,
    email: null,
    displayName: null,
    photoUrl: null,
    errorMessage: null,

  },
  reducers: {

    login: (state, {payload}) => {
    
      state.status= 'autenticate'; // checking, not-autenticate, autenticated
      state.uuid= payload.uid;
      state.email= payload.email;
      state.displayName= payload.displayName;
      state.photoUrl= payload.photoURL;
      state.errorMessage= null;
    },

    logout: (state, payload) => {

      state.status= 'not-autenticate'; // checking, not-autenticate, autenticated
      state.uuid= null;
      state.email= null;
      state.displayName= null;
      state.photoUrl= null;
      state.errorMessage= payload.errorMessage;
    },

    checkingCredentials: (state) => {

        state.status = 'checking';
    },
  },
})

export const { login, logout, checkingCredentials } = authSlice.actions
