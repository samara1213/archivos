import { loginUser, logoutFirebase, registerUser, singInWithGoogle } from "../../firebase/providers";
import { clearNotesLogout } from "../journal/journalSlice";
import { checkingCredentials, login, logout } from "./authSlice";

export const chekingAutentication = (email, password) => {

    return async(dispatch) => {

        dispatch(checkingCredentials());
    }    

}

export const startGoogleSingIn = (email, password) => {

    return async(dispatch) => {

        dispatch(checkingCredentials());
        const result = await singInWithGoogle();

        console.log(result);

        if(!result.ok) return dispatch(logout('error en la autenticacion'));

        dispatch(login(result));
    }    

}

export const startUserWithEmailAndPassword = ({dysplayName, email, password}) => {
    
    console.log(dysplayName, email, password);
    return async(dispatch) => {

        dispatch(checkingCredentials());
        const resp = await registerUser({dysplayName, email, password});

        console.log(resp);
    }
}

export const loginUse = ({email, password}) => {

    return async(dispatch) => {

        dispatch(checkingCredentials());
        const result = await loginUser({email, password});       

        console.log(result);

        if(!result.ok) return dispatch(logout('error en la autenticacion'));

        dispatch(login(result));
    }   
}

export const logoutSinInFirebase = () => {

    return async(dispatch) => {

        await logoutFirebase();

        dispatch(clearNotesLogout())
        dispatch(logout({}));
    }

}