import { collection, deleteDoc, doc, setDoc } from "firebase/firestore/lite";
import { FirebaseDB } from "../../firebase/config";
import { addNewEmptyNote, deleteNoteById, isSaving, setActiveNote, setNotes, setPhotoByNote, setUpdate } from "./journalSlice";
import { fileUpload, loadNotes } from "../../helpers";



export const startNewNote = () => {

    return async(dispatch, getState) => {

        dispatch(isSaving());
        //uuid user
        const {uuid} = getState().auth;


        const newNote = {

            title: '',
            body: '',
            date: new Date().getTime(),
        }

        const newDoc = doc( collection(FirebaseDB, `${ uuid}/react/notes`));

        await setDoc( newDoc, newNote);

        newNote.id = newDoc.id;

        dispatch(addNewEmptyNote(newNote));

        dispatch(setActiveNote(newNote));

        

    }     
}

export const starLoadingNotes =() => {

    return async(dispatch, getState) => {

        const {uuid} = getState().auth;

       const notes =  await loadNotes(uuid);

       dispatch(setNotes(notes));
    }
}

// esta es la forma en la que se actualiza un nota en firebase
export const startSaveNote = () => {

    return async(dispatch, getState) => {

        const {uuid} = getState().auth;

        const {active:note} = getState().journal;

        // desectructuramos la nota para eliminar el id 
        const noteFireStore = {...note};

        // se elimina el id del objecto
        delete noteFireStore.id;

        // creamos la referencia del objecto a actualizar
        const docRef = doc(FirebaseDB, `${ uuid}/react/notes/${note.id}`);

        // se actualiza el documento en firebase se coloca merge en true para que actualice e iserte lo nuevo
        await setDoc(docRef, noteFireStore, {merge:true});

        // se actualiza la nota en el listado
        dispatch(setUpdate(note));
    }
}

// metodo para subir archivos a cloudinary

export const startUploadsFiles = (files = []) => {

    return async(dispatch) => {

        // asi se carga una sola imagen
        //const respo = await fileUpload(files[0]);

        // asi se cargarian todas la imagenes al tiempo
        const  fileUploadPromises = [];

        for( const file of files) {

            fileUploadPromises.push(fileUpload(file));
        }

       const respose = await Promise.all(fileUploadPromises);

       dispatch(setPhotoByNote(respose));

   
    }
}


// de esta forma eliminamos una nota 
export const startOndeleteNote = () => {

    return async(dispatch, getState) => {

        const {uuid} = getState().auth;
        const {active:note} = getState().journal;
        
        const ref = doc(FirebaseDB, `${ uuid }/react/notes/${note.id}` ) 

        await deleteDoc(ref);

        // se quita la nota activa
        dispatch(deleteNoteById(note.id));

    }
}