import { useEffect, useMemo, useState } from 'react';

export const useForm = ( initialForm = {}, formValidator = {} ) => {
  
    const [ formState, setFormState ] = useState( initialForm );

    const [formValidations, setFormValidations] = useState({

    })
    useEffect(() => {
        createValidations();

    }, [formState])

    useEffect(() => {
        
        setFormState(initialForm);

    }, [initialForm])
    
    const isFormValid = useMemo(() => {
        
        for (const formField of Object.keys(formValidations)) {            

            if(formValidations[formField] !== null) return false;
        }
        return true;
    }, [formValidations]);

    const onInputChange = ({ target }) => {
        const { name, value } = target;
        setFormState({
            ...formState,
            [ name ]: value
        });
    }

    const onResetForm = () => {
        setFormState( initialForm );
    }

    const createValidations = () => {

        const formCheckValues = {};

        // recorremos todos los campos del formulario a validar
        for (const formField of Object.keys(formValidator)) {

            const [funcion,errorMessage] = formValidator[formField];
          

            formCheckValues[`${formField}Valid`] = funcion(formState[formField]) ? null:errorMessage;

        }

        setFormValidations(formCheckValues);
    }

    return {
        ...formState,
        formState,
        onInputChange,
        onResetForm,
        ...formValidations,
        isFormValid,
    }
}