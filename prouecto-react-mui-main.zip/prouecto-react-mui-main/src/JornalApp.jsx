import { RouterApp } from "./router/RouterApp"
import { AppTheme } from "./theme"


export const JornalApp = () => {
  return (
   
    <AppTheme>
      <RouterApp/>
    </AppTheme>
  )
}
