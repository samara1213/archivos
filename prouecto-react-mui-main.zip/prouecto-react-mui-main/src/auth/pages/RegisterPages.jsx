import { Button, Grid, Link, TextField, Typography } from "@mui/material"
import { Link as routerLink } from "react-router-dom"
import { AuthLayout } from "../layout/AuthLayout"
import { useForm } from "../../hooks"
import { useState } from "react"
import { useDispatch } from "react-redux"
import { startUserWithEmailAndPassword } from "../../store/auth"

const initialData = {
  dysplayName: '',
  email: '',
  password: '',
}

const formValidator = {
  dysplayName: [(value) => value.length >= 6, 'el nombre debe ser de mas de 6 caracteres'],
  email: [(value) => value.includes('@'), 'El correo no es valido'],
  password: [(value) => value.length >= 1, 'La contraseña debe ser de mas de 6 caracteres'],
}



export const RegisterPages = () => {
 
  const dispatch = useDispatch();
  const  [formSubmit, setFormSubmit] = useState(false);

  const {dysplayName,email,password, onInputChange, formState,
         dysplayNameValid,emailValid,passwordValid,isFormValid,
  } = useForm(initialData,formValidator);

  // esta funcion se utiliza para evitar envitar enviar el formulario dos veces
  const onSubmit = (event) => {

    event.preventDefault();
    setFormSubmit(true);
    console.log(isFormValid);
    if(!isFormValid) return ;  
   
    dispatch(startUserWithEmailAndPassword(formState));

  }
 
  return (

    <AuthLayout title="Register">
      <h1>Formulario: {isFormValid ? 'Valido': 'Invalido'}</h1>
      <form onSubmit={onSubmit}>
        <Grid container>
        <Grid item xs={12} sx={{ mt: 2 }}>
            <TextField
              label="Nombre Completo"
              type="text"
              placeholder='Ingrese su nombre '
              fullWidth
              name="dysplayName"
              value={dysplayName}
              onChange={onInputChange}
              error={!!dysplayNameValid && formSubmit}
              helperText={dysplayNameValid}
               />
          </Grid>
          <Grid item xs={12} sx={{ mt: 2 }}>
            <TextField
              label="Correo"
              type="email"
              placeholder='Ingrese su correo'
              fullWidth
              name="email"
              value={email}
              onChange={onInputChange}
              error={!!emailValid && formSubmit}
              helperText={emailValid}
              />
          </Grid>
          <Grid item xs={12} sx={{ mt: 2 }}>
            <TextField
              label="Password"
              type="password"
              placeholder='Ingrese su contraseña'
              fullWidth
              name="password"
              value={password}
              onChange={onInputChange}
              error={!!passwordValid && formSubmit}
              helperText={passwordValid}
               />
          </Grid>
        </Grid>
        <Grid container spacing={2} sx={{ mb: 2, mt: 1 }} >
          <Grid item xs={12}>
            <Button 
              onClick={onSubmit}
              variant='contained' fullWidth>
              Crear Cuenta
            </Button>
          </Grid>
          <Grid container direction='row' justifyContent='end'>
          <Typography>
                Ya tienes cuenta?
          </Typography>
            <Link component={routerLink} color='inherit' to="/auth/login">  
              INGRESAR
            </Link>
          </Grid>
        </Grid>
      </form>
    </AuthLayout>


  )
}
