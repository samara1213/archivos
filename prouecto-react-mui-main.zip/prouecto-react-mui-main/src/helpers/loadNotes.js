import { collection, getDocs } from "firebase/firestore/lite"
import { FirebaseDB } from "../firebase/config"


export const loadNotes = async (uuid = '') => {

    const collectionRef = collection(FirebaseDB, `${ uuid}/react/notes`);

    const docs = await getDocs(collectionRef);

    const notes = [];

   
    docs.forEach(doc => {
        
        notes.push({id: doc.id, ...doc.data()});
    })

    return notes;



}