

export const fileUpload = async(file) => {


    const urlCloudinary = 'https://api.cloudinary.com/v1_1/dbkhi0qpr/upload';

    const formDate = new FormData();

    formDate.append('upload_preset','react-journal');
    formDate.append('file',file);

    try {

        const response = await fetch(urlCloudinary,{
            method:'POST',
            body:formDate
        })     

        if(!response.ok) throw new Error('no se pudo cargar imagen')

        const respoCloudi = await response.json();

        return respoCloudi.secure_url;

        
    } catch (error) {
     
        console.log(error);

        throw new Error(error);
        
    }
}