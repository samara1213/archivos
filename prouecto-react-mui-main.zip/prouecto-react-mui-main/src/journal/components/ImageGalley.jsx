import { ImageList, ImageListItem } from "@mui/material";


export const ImageGalley = ({itemData= []}) => {
  return (
    <ImageList sx={{ width: '100%', height: 500 }} cols={4} rowHeight={200}>
      {itemData.map((itemData) => (
        <ImageListItem key={itemData}>
          <img
            src={`${itemData}?w=164&h=164&fit=crop&auto=format`}
            srcSet={`${itemData}?w=164&h=164&fit=crop&auto=format&dpr=2 2x`}
            alt="imagen de la nota"
            loading="lazy"
          />
        </ImageListItem>
      ))}
    </ImageList>
  );
}

