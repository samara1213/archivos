
import { Box, Divider, Drawer, Grid, List, ListItem, ListItemButton, ListItemIcon, ListItemText, Toolbar, Typography } from "@mui/material"
import { TurnedInNot } from "@mui/icons-material"
import { useDispatch } from "react-redux"
import { setActiveNote } from "../../store/journal/journalSlice";


export const SideBarItem = ({body,date,title,id, imagesUrl}) => {
    
    const dispatch = useDispatch();    

    const onClickNote = () => {

        dispatch(setActiveNote({body,date,title,id,imagesUrl}));
    }
    
    return (
        <ListItem key={id} disablePadding>
            <ListItemButton
            onClick={onClickNote}>
                <ListItemIcon>
                    <TurnedInNot />
                </ListItemIcon>
                <Grid container>
                    <ListItemText primary={title} />
                    <ListItemText secondary={body} />
                </Grid>
            </ListItemButton>
        </ListItem>
    
  )
}
