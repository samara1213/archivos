// Import the functions you need from the SDKs you need
import { initializeApp } from 'firebase/app';
import {  getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore/lite'
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAM0mNAl5XNUUAUxjva9t9v_3BE7dQ0hCo",
  authDomain: "react-b58bc.firebaseapp.com",
  projectId: "react-b58bc",
  storageBucket: "react-b58bc.appspot.com",
  messagingSenderId: "102580784033",
  appId: "1:102580784033:web:5c7d493bd89ee53e7219e0"
};

// Initialize Firebase
export const FirebaseApp = initializeApp(firebaseConfig);

export const FirebaseAuth = getAuth(FirebaseApp);

export const FirebaseDB = getFirestore(FirebaseApp);
