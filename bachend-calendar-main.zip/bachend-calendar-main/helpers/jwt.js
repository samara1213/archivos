
const jwt = require('jsonwebtoken');

const generarJWT = (uid, name) => {

    
    return new Promise((resolve, reject) => {

        const payload = {uid,name};

        jwt.sign(payload,process.env.KEYTOKEN,{
            expiresIn: '2h' // duracion en expirar el token
        },(err,token) => {

            if(err) {
                console.log(err);
                reject('no se pudo generar token')
            }
            
            resolve(token);
        })
    })
}

module.exports= {
    generarJWT,
}