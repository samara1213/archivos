
const moment = require('moment');

const isDate = (value ) => {

    //validamos si el campo tiene datos
    if(!value) {
        return false;
    }

    //se pasa el valor a una fecha correcta
    const fecha = moment(value);

    if (fecha.isValid()){

        return true;
    }
    else {
        return false;
    }
}

module.exports ={
    isDate,  
}