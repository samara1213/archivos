const {Router} = require('express');
const {check} = require('express-validator');
const {validarCampos} = require('../middlewares/validar-campos');
const {validarJWT} = require('../middlewares/validar-jwt');


const router = Router();




// rutas e usuarios
const {
    crearUsuario,
    loginUser,
    renToken
        } = require('../controllers/auth');

router.post(
    '/new',
    [
      // aca llamamos nuestros midelwares
      check('name','nombre es obligatorio').not().isEmpty(),// se esta diciendo que el campo nombre es obligatorio
      check('email','Correo no valido').isEmail(),// se esta diciendo que el campo nombre es obligatorio
      check('password','contraseña debe ser de mas de 6 letras').isLength({min:6}),
      validarCampos,// este es nuestro middlerware que valida si los campos del formuario estan ok
    ],
    crearUsuario);

 router.post(
    '/',
    [
        check('email','Correo no valido').isEmail(),// se esta diciendo que el campo nombre es obligatorio
        check('password','contraseña debe ser de mas de 6 letras').isLength({min:6}),
        validarCampos,
     
    ],
    loginUser);

 router.get('/reNew',validarJWT,renToken);

 module.exports = router;