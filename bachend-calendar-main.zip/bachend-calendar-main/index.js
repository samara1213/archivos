
const express = require('express');
require('dotenv').config();
const {dbConnection} = require('./databases/config');
const cors = require('cors')





// se crea el servidor de express
const app = express();

//se conecta a la base de datos
dbConnection();

//CORS de la apliacion
app.use(cors())

//conectar bas e datos

//7lectura y parseo del body
app.use(express.json());

//RUTAS
// rutas de usuario autenticacion crear usuario logion
app.use('/api/auth', require('./routes/auth'));
app.use('/api/events', require('./routes/events'));

// se escuchan las peticiones
app.listen(process.env.PORT, () => {
    console.log('servidor corriendo');
})