
const { response } = require('express');
const Usuario = require('../models/Usuario');
const bcrypt = require('bcryptjs');
const {generarJWT} = require('../helpers/jwt');


const crearUsuario = async (req, res = response) => {

    try {

        const { email, password } = req.body;
        //Validamos si el suuario no existe en la base de datos
        let usuario = await Usuario.findOne({ email });

        if (usuario) {
            return res.status(400).json({
                "msg": 'Ya existe usuario con el correo ingresado'
            })
        }
        // se crea el nuevo usuario con los datos
        usuario = new Usuario(req.body);

        //se encripta la contraseña
        const salt = bcrypt.genSaltSync();

        usuario.password = bcrypt.hashSync(password, salt);

        // se graba los datos en la base de datos
        await usuario.save();

        //se genera el token
        const token = await generarJWT(usuario.id, usuario.name);

        const {name,id} = usuario;

        res.json({

            "ok": true,
            "msg": 'usuario Creado ok',
            token,
            name,
            id

        });
    } catch (error) {

        console.log(error);

        res.status(500).json({
            "msg": 'error creando usuario'
        });
    }

}

const loginUser = async (req, res = response) => {

    try {

        const { email, password } = req.body;
        //Validamos si el suuario no existe en la base de datos
        const usuario = await Usuario.findOne({ email });

        if (!usuario) {
            return res.status(400).json({
                "msg": 'no existe usuario con el correo ingresado'
            })
        }

        //validar las contraseñas la que se envia contra la que esta guardada
        const valiPassword = bcrypt.compareSync(password, usuario.password);

        //Validamos si la contraseña no es validad
        if (!valiPassword) {
            return res.status(400).json({
                "msg": 'no existe usuario con el contraseña ingresado'
            })
        }
    
        //generamos el JwT
        //se genera el token
        const token = await generarJWT(usuario.id, usuario.name);

        const {name,id} = usuario;
        return res.json({

            "ok": true,
            "msg": "login",
            token,
            name,
            id,

        })

    } catch (error) {

        console.log(error);

        res.status(500).json({
            "msg": 'error creando usuario'
        });

    }

}

const renToken = async(req, res = response) => {

    const uid = req.uid;
    const name = req.name;

    // se genera un nuevo toekn
    const token = await generarJWT(uid, name);

    return res.json({

        "ok": true,
        "msg": "regenracion de toekn",
        token,
        name,
        uid,
    })
}

module.exports = {
    crearUsuario,
    loginUser,
    renToken,
}
