
const { response } = require('express');
const Evento = require('../models/Evento');

const getEvents = async (req, res = response) => {

    try {
        const eventos = await Evento.find()
                                    .populate('user','name');
                                    /**
                                     * el pupulate se utiliza para las refrencia de otras tablas
                                     * el promer valor hace refrencia el campo que tiene la relacion
                                     * en ya depsues se colocan los campos de la tabla que tiene la relacion
                                     * que deseamos mostrat ejemplo 'name id edad'
                                     */

        res.status(200).json({
            "ok": true,
            eventos
        });
        
    } catch (error) {
        console.log(error);

        return res.status(500).json({
            "msg": 'error del servidor'
        })
        
    }

}

const createEvents = async(req, res = response) => {
    
    try {

        
        const evento = new Evento(req.body);

        //agregamos el usuario
        evento.user = req.uid;

        const result = await evento.save();

        res.status(201).json({
            "msg":'creacion ok',
            result
        })
        
    } catch (error) {
        console.log(error);
         res.status(500).json({
            "msg":  'error en el servidor',
        })
    }
}

const updateEvents = async(req, res = response) => {

    try {
        // se obtiene el id enviado como parametro en la ruta
        const eventoId = req.params.id;
        // se consulta el evento por el id
        const evento = Evento.findById(eventoId);

        const userId = req.uid;

        //7validamos si existe el evento
        if(!evento) {
            return res.status(404).json({
                "msg": 'no existe data con el id'
            })
        }
        //validamos si la nota a editra es del mismo usuario que la creo
        // if(evento.user.toString() !== userId) {

        //     return res.status(404).json({
        //         "msg": 'el usuario no es mismo que lo creo'
        //     })
        // }

        //creamos el nuevo evento
        const nuevoEvent = {
            ...req.body, // se desectructura lo que viene en el body de la peticion
            user: userId
        }

        //se actualiza en la base de datos
        // se le pase el id del  evento y el objecto con los nuevos datos
        const eventoUpdate = await Evento.findByIdAndUpdate(eventoId,nuevoEvent,{new:true});

        res.status(200).json({
            "msg": 'Datos actualizados',
            eventoUpdate
        })

        
    } catch (error) {
        
        console.log(error);
        return res.status(500).json({
            "msg": 'error en el servidor'
        })
    }

}

const deleteEvent = async (req, res = response) => {

    try {
        // se obtiene el id enviado como parametro en la ruta
        const eventoId = req.params.id;        
        // se consulta el evento por el id
        const evento = Evento.findById(eventoId);

        const userId = req.uid;

        
        //7validamos si existe el evento
        if(!evento) {
            return res.status(404).json({
                "msg": 'no existe data con el id'
            })
        }
        //validamos si la nota a editra es del mismo usuario que la creo
        // if(evento.user.toString() !== userId) {

        //     return res.status(404).json({
        //         "msg": 'el usuario no es mismo que lo creo'
        //     })
        // }



        //se elimina en la base de datos
        // se le pase el id del  evento 
        await Evento.findByIdAndDelete(eventoId);

        res.status(200).json({
            "msg": 'Datos eliminados'
            
        })

        
    } catch (error) {
        
        console.log(error);
        return res.status(500).json({
            "msg": 'error en el servidor'
        })
    }

}

module.exports = {
    getEvents,
    createEvents,
    updateEvents,
    deleteEvent,
}