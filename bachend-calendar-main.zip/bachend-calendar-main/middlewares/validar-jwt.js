
const {response} = require('express');
const jwt = require('jsonwebtoken');

const validarJWT = (req, res=response, next) => {

    //leemos el token d elos headers
    // el parametro que tiene el token es x-token
    const token = req.header('x-token');
   
    //validamos si tenemos el token en la peticion
    if(!token){

        return res.status(401).json({
            "msg": 'no hay toekn en la peticion'
        })
    };

    try {

        //validamos el toekn que se envio
        const  {uid,name} = jwt.verify(
            token,
            process.env.KEYTOKEN
        );
        req.uid = uid;
        req.name = name;

        
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            "msg": 'error de servidor'
        })
        
    }
    next();
}

module.exports={
    validarJWT
}