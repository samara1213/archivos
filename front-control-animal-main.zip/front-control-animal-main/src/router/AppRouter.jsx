import { Navigate, Route, Routes } from "react-router-dom"
import { AuthRoutes } from "../componentes/auth/routes/AuthRoutes"
import { useAuthStore } from "../componentes/hooks";
import { useEffect } from "react";
import { Home } from "../componentes/home/Home";
import { PrincipalRoute } from "../componentes/router/PrincipalRoute";


export const AppRouter = () => {

    // const {autenticaded, checkAuthToken} = useAuthStore(); 
    

    // useEffect(() => {
    //     checkAuthToken();
    // }, [])
    const autenticaded = 'autenticaded'

    return (
        <>
        <Routes>
            {
                (autenticaded === 'no-autenticaded')
                    ? (
                        <>
                            <Route path="/auth/*" element={ <AuthRoutes /> } />
                            <Route path="/*" element={ <Navigate to="/auth/login" /> }/>
                        </>
                    )
                     
                    : (
                        <>
                            <Route path="/*" element={ <PrincipalRoute /> } />
                            {/* <Route path="/*" element={ <Navigate to="/" /> }/>  */}
                        </>
                    )
            }
         
                       
          
        </Routes>

        </>
    )
}