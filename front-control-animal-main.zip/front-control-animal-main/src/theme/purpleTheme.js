import { createTheme } from "@mui/material";
import { red } from "@mui/material/colors";

export const purpleTheme = createTheme ({

    palette: {
        primary: {
            main: '#1976D2'
        },
        secondary: {
            main: '#ffffff'
        },
        error: {
            main: red.A400
        }

    }
})