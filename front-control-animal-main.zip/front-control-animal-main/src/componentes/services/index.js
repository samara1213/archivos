export { getRazasDB, createRazaDB} from "./razasService";
export { getClasificacionAnimalDB, createClasiAninalDB, updateClasiAnimalDB } from "./clasAnimalService";
export { getFincasDB, createFincaDB, editFincaDB } from "./fincasService";





