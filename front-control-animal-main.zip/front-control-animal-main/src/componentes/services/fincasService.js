import { controlAnimalApi } from "../api"

export async function getFincasDB() {
    
    return await controlAnimalApi.get('/fincas');
}

export async function createFincaDB(data) {

    return await controlAnimalApi.post('/fincas', data);
}

export async function editFincaDB(data, id_finca) {

    return  await controlAnimalApi.patch(`/fincas/${id_finca}`, data);
}