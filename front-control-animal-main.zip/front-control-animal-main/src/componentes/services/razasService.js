import { controlAnimalApi } from "../api";


export async function getRazasDB() {

    return await controlAnimalApi.get('/razas');
}
export async function createRazaDB(data) {

    return await controlAnimalApi.post('/razas', data);
}