import { controlAnimalApi } from "../api";

export async function getClasificacionAnimalDB() {

    return await controlAnimalApi.get('/clasificacio-animales');

}

export async function createClasiAninalDB(data) {

    return await controlAnimalApi.post('/clasificacio-animales', data);
}

export async function updateClasiAnimalDB(id_clas, data) {

    return await controlAnimalApi.patch(`/clasificacio-animales/${id_clas}`, data);
}