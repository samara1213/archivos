import { Box, Button, Grid, IconButton, Typography } from "@mui/material"
import { SideNav } from "../../sidenav/SideNav"
import { DataGrid } from "@mui/x-data-grid"
import { useUiStore } from "../../hooks";
import { useEffect, useState } from "react";
import { getRazasDB } from "../../services";
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css'
import { AddBoxOutlined, EditOutlined } from "@mui/icons-material";
import { ModalCreateRazas } from "./ModalCreateRazas";

export const RazasPage = () => {

    const columns = [

        { field: 'id_raza', headerName: 'ID', width: 150 },
        { field: 'nombre_raza', headerName: 'NOMBRE RAZA', width: 300},
        { field: 'nombre_clas', headerName: 'CLASIFICACION ANIMAL', width: 250},
        { field: 'edit', headerName: 'EDITAR', width: 100,
          renderCell: (params) => (        
           <IconButton onClick={() => dataRegistro(params.row)}>
           <EditOutlined />
          </IconButton>
          ),  
        }, 
      
      ];
      const { modalCreateFincaOpen } = useUiStore();
      const [editRaza, setEditRaza] = useState({})
      const [razas, setRazas] = useState([])
      const [typeModal, setTypeModal] = useState(0)

  /**
   * metodo que llama el servicio del api para obtener el listado de fincas
   */
  const getRazas = async () => {

    try {

      const respuesta = await getRazasDB();

      const lstRazas = respuesta.data.map((itemRaza) => ({
        id_raza:              itemRaza.id_raza,
        nombre_raza:          itemRaza.nombre_raza,
        creacion_raza:        itemRaza.creacion_raza,
        modificacion_raza:    itemRaza.modificacion_raza,
        clasificacionAnimal:  itemRaza.clasificacionAnimal,    
        nombre_clas:          itemRaza.clasificacionAnimal.nombre_clas
      })); 
        setRazas(lstRazas);
      
    } catch (error) {
      
      console.log("********ERROR EN CONSULTA RAZAS");
      console.log(error);

      Swal.fire('Razas', '!Ohs se presento un error', 'error');
    }

  }

  useEffect(() => {

    // obtener la razas
    getRazas();  

  }, [])
  

   /**
   * funcion para abrir el modal de crear
   */
  const openModalCreate = () => {

    modalCreateFincaOpen();
    setTypeModal(1);
    }

  /**
   * funcion para abrir el modal de editar
   */
  const openModalEdit = () => {

    modalCreateFincaOpen();
    setTypeModal(2);
 }

  /**
  * metodo para ontener el registro seleccionado
  * @param {} registro seleccionado 
  */
  const dataRegistro = (registro) => {

    console.log(registro);
    setEditRaza(registro);
    openModalEdit();

  }


  const getRowId = (fila) => fila.id_raza;
  return (
    <>
     <Box sx={{ display: 'flex'}}>
            <SideNav />
            <Box component="main" sx={{ flexGrow: 1, p: 8}}>
                <Grid container sx={{mt:5}}>
                    <Typography variant="h6" sx={{mb:4}}>
                        Razas de Animales
                    </Typography>
                    <Grid container>
                        <Button
                        startIcon={<AddBoxOutlined></AddBoxOutlined>}
                        onClick={openModalCreate}
                        >
                        Agregar Nuevo
                        </Button>
                    </Grid>
                    <Grid item>               
                        <DataGrid
                            sx={{height:'auto', width:'100%', mt:2}}
                            columns={columns}
                            rows={razas}
                            getRowId={getRowId}
                            initialState={{
                                pagination: {
                                paginationModel: { page: 0, pageSize: 5 },
                                },
                            }}
                            pageSizeOptions={[5, 10]}
                        >

                        </DataGrid>
                    </Grid>
                </Grid>
            </Box>
        </Box>
     <ModalCreateRazas actualizarTabla={getRazas} typeModal={typeModal} />
   {/* <ModalEditarFinca actualizarTabla={getFincas} dataFinca={editFinca} typeModal={typeModal} /> */}
    
    </>
  )
}
