import Modal from 'react-modal';
import { useForm, useUiStore } from '../../hooks';
import { Button, FormControl, Grid, InputLabel, MenuItem, Select, TextField, Typography } from '@mui/material';
import { useState } from 'react';
import { useEffect } from 'react';
import { createRazaDB, getClasificacionAnimalDB } from '../../services';
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css'
import { CloseOutlined, SaveAsOutlined } from '@mui/icons-material';

const customStyles = {
    content: {
      top: '50%',
      left: '60%',
      right: 'auto',
      bottom: 'auto',
      marginRight: 'auto',
      transform: 'translate(-50%, -50%)',
    },
  };
  Modal.setAppElement('#root');
export const ModalCreateRazas = ({actualizarTabla, typeModal}) => {

    const { openModalCreateFinca, modalCreateFincaClose } = useUiStore();
    const [opcionSeleccionada, setOpcionSeleccionada] = useState('opcion1')
    const [clasificaAnimal, setClasificaAnimal] = useState([]);
    const { formState, onInputChange} = useForm({        
        name: '',
    });

    const closeModal = () => {

        modalCreateFincaClose();
    }

    const handlerChangueClasifiAnimal = (event) => {

        const opcionClasificacion = event.target.value;    

        setOpcionSeleccionada(opcionClasificacion);

    }

    const getClasificacionAnimal = async () => {

        try {
            
            const respuesta = await getClasificacionAnimalDB();
            
            setClasificaAnimal(respuesta.data);

            
        } catch (error) {

            console.log("############# ERROR LISTANDO  CLASIFICACIONES #############");
            console.log(error);
            Swal.fire('Clasificacion Animal', '!Ohs se presento un error', 'error');
            
        }
      }

    const createRaza = async (data) => {
        try {

            await createRazaDB(data);

            // mensaje de confirmacion
            Swal.fire('Razas', 'Se agrego correctamente la data', 'success');

            // se actualiza la tabla con los registro insertado
            actualizarTabla();
            
        } catch (error) {
            
            console.log("############# ERROR creando raza #############");
            console.log(error);
            Swal.fire('Razas', '!Ohs se presento un error', 'error');
        }
    }

    useEffect(() => {

        formState.name = '';
        setOpcionSeleccionada('opcion1')
        if(typeModal == 1 && openModalCreateFinca) {
          getClasificacionAnimal();      
        }        
     
    }, [openModalCreateFinca])

    const onSubmit = (event) => {

        event.preventDefault();

        const data = {
            "id_clasificacion_animal": opcionSeleccionada,
            "nombre_raza": formState.name
        }       

        // se envia a crear la raza de animales
        createRaza(data);
        
        modalCreateFincaClose();

    }
    
  return (
    <>
    <Modal
         isOpen={typeModal === 1 ? openModalCreateFinca : false}
        style={customStyles}
        onRequestClose={closeModal} >
            <Typography variant='h5'sx={{mb:2}}>
                Crear raza de animales
            </Typography>
            <form onSubmit={ onSubmit }>
                <Grid container>
                    <Grid item xs={12} sm={9} md={10} lg={10} xl={4} sx={{m:1}}>
                        <FormControl>
                            <InputLabel id="demo-controlled-open-select-label">Clasificacion</InputLabel>
                            <Select
                                labelId="demo-controlled-open-select-label"
                                id="demo-controlled-open-select"                               
                                label="Clasificacion"
                                value={opcionSeleccionada}
                                onChange={handlerChangueClasifiAnimal}
                            >
                                 <MenuItem value="opcion1">Seleccione opcion</MenuItem>
                                {
                                    clasificaAnimal.map((clasif) => (
                                        <MenuItem key={clasif.id_clas} value={clasif.id_clas}>
                                            {clasif.nombre_clas}
                                        </MenuItem>
                                    ))
                                }
                            </Select>                            
                        </FormControl>
                    </Grid>
                    <Grid item xs={12} sm={9} md={10} lg={10} xl={4} sx={{m:1}}>
                        <TextField
                            label="Name"
                            type="text"
                            name='name'
                            value={formState.name}
                            placeholder="Ingresa nombre de la raza"
                            fullWidth
                            onChange={onInputChange}
                        />
                    </Grid>
                </Grid>
                <Grid container>
                <Grid item xs={12} sm={9} md={5} lg={12} xl={4} sx={{m:1}}>                    
                    <Button variant="contained"                         
                            type='submit'
                            startIcon={<SaveAsOutlined></SaveAsOutlined>}
                            sx={{m:2}}
                            xs={12}                                
                    >
                    <Typography sx={{ color: 'white' }}> guardar</Typography>
                    </Button>
                    <Button variant="contained"
                            startIcon={<CloseOutlined></CloseOutlined>}
                            sx={{m:2, backgroundColor:'red'}}
                            xs={12}
                            onClick={closeModal}
                    >
                    <Typography sx={{ color: 'white' }}> Cancelar</Typography>
                    </Button>
                </Grid>
            </Grid>
            </form>
    </Modal>
    </>
  )
}
