
import { SideNav } from '../sidenav/SideNav'
import { Box, Typography } from '@mui/material'

export const Home = () => {
  return (
    <>
     <Box sx={{ display: 'flex' }}>
        <SideNav/> 
        <Box component="main" sx={{ flexGrow: 1, p: 8 }}>
        <Typography variant="h6">
        Home
        </Typography>
        </Box>          
     </Box>
    </>
  )
}
