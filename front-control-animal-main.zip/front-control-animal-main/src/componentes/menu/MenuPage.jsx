import { AssignmentOutlined, BlockOutlined, BusinessOutlined, CommentOutlined, HouseOutlined, Inbox } from "@mui/icons-material"
import { ListItem, ListItemButton, ListItemIcon, ListItemText, Typography } from "@mui/material"
import { useNavigate } from "react-router-dom"


export const MenuPage = () => {
 
    const navigateRutas = useNavigate();
    return (
        <>        
            <Typography variant="h6" noWrap component="div" sx={{ textAlign: 'center', mt: 2 }}>
                Menu Principal
            </Typography>
            <ListItem disablePadding onClick={()=>{navigateRutas("/")}}>
                <ListItemButton>
                    <ListItemIcon>
                        <HouseOutlined />
                    </ListItemIcon>
                    <ListItemText primary="Home" />
                </ListItemButton>
            </ListItem>
            <ListItem disablePadding onClick={()=>{navigateRutas("/fincas")}}>
                <ListItemButton>
                    <ListItemIcon>
                        <BusinessOutlined />
                    </ListItemIcon>
                    <ListItemText primary="Fincas" />                  
                </ListItemButton>
            </ListItem>
            <ListItem disablePadding onClick={()=>{navigateRutas("/clas-animal")}}>
                <ListItemButton>
                    <ListItemIcon>
                        <AssignmentOutlined/>
                    </ListItemIcon>
                    <ListItemText primary="Clasificacion Animal" />                  
                </ListItemButton>
            </ListItem>
            <ListItem disablePadding onClick={()=>{navigateRutas("/razas")}}>
                <ListItemButton>
                    <ListItemIcon>
                        <CommentOutlined/>
                    </ListItemIcon>
                    <ListItemText primary="Razas Animales" />                  
                </ListItemButton>
            </ListItem>
        </>
    )
}
