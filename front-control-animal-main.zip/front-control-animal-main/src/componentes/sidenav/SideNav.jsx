import { ChevronLeft, MenuOutlined, PowerSettingsNewOutlined } from '@mui/icons-material'
import { AppBar, Box, Divider, Drawer, IconButton, Toolbar, Tooltip, Typography } from '@mui/material'
import { useState } from 'react'
import { MenuPage } from '../menu/MenuPage';

const withDrawer = 240;

export const SideNav = () => {

    const finca = 'Finca el miradosxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx';

    const [open, setOpen] = useState(true);

    const handleDrawerOpen = () => {

        setOpen(true)
        // setdireccion('open')
    }
    const handleDrawerClose = () => {

        setOpen(false)
        // setdireccion('close')
    }

    return (
        <>
            <Box sx={{ display: 'flex' }}>
                <AppBar position="fixed" open={open}
                    sx={{
                        ...(open && { width: { sm: `calc(100% - ${withDrawer}px)` } }),
                    }}
                >
                    <Toolbar>
                        <IconButton
                            color="inherit"
                            aria-label="open drawer"
                            onClick={handleDrawerOpen}
                            edge="start"
                            sx={{
                                marginRight: 3,
                                ...(open && { display: 'none' }),
                            }}
                        >
                            <MenuOutlined />
                        </IconButton>
                        <Typography variant="h6" noWrap component="div" sx={{
                            marginRight: `calc(100% - 40%)`,
                        }}>
                            {finca}
                        </Typography>
                        <Tooltip title="Salir">
                            <IconButton
                                color="inherit"
                            >
                                <PowerSettingsNewOutlined />
                            </IconButton>
                            
                        </Tooltip>
             
                    </Toolbar>

                </AppBar>
                <Drawer
                    sx={{
                        width: withDrawer,
                        flexShrink: 0,
                        '& .MuiDrawer-paper': {
                            width: withDrawer,

                        },
                    }}
                    variant="persistent"
                    anchor="left"
                    open={open}

                >   <Typography sx={{ textAlign: 'right', mb: 1 }}>
                        <IconButton onClick={handleDrawerClose} sx={{ width: '40px', height: '40px', mt: 2 }}>
                            <ChevronLeft />
                        </IconButton>
                    </Typography>
                    <Divider />
                    <MenuPage />
                </Drawer>
            </Box>
        </>
    )
}
