import { configureStore } from "@reduxjs/toolkit";
import { userSlice } from "./user/userSlice";
import { authSlice } from "./auth/authSlice";
import { uiSlice } from "./ui/uiSlice";

export const store = configureStore({

    reducer: {
        user  : userSlice.reducer,
        auth  : authSlice.reducer,
        ui    : uiSlice.reducer,
    }
})