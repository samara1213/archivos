import { createSlice } from "@reduxjs/toolkit";


export const userSlice = createSlice({
    name: 'user',
    initialState: {
        dataUser: {},
        errorMessage: '',
    },
    reducers: {

        isLoginUser: (state, { payload }) => {

            state.dataUser = payload;
        },
        isLogoutUser: (state) => {

            state.dataUser = {};
        },

        onErrorLogin: (state, {payload}) => {

            state.errorMessage = payload;
        },
    }
});

export const {isLoginUser, isLogoutUser, onErrorLogin} = userSlice.actions;