import { createSlice } from "@reduxjs/toolkit";

export const uiSlice = createSlice({
    name: 'ui',
    initialState: {
        openModalCreateFinca: false,     
    },
    reducers: {

        isOpenModalCreateFinca: (state) => {

            state.openModalCreateFinca = true;
        },
        isCloseModalCreateFinca: (state) => {

            state.openModalCreateFinca = false;
        }
    }
});

export const {isOpenModalCreateFinca,
             isCloseModalCreateFinca,} = uiSlice.actions;