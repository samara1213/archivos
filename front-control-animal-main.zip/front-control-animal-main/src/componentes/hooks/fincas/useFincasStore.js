import { FincasSerices } from "../../services"


export const useFincasStore = () => {

    const fincaservice = new FincasSerices();

    const getFincas = async () => {        

        const data = await fincaservice.getFincasDB();
    }

    return {
        getFincas,
    }
}