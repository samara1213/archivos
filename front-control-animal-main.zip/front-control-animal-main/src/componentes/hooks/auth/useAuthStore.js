import { useDispatch, useSelector } from "react-redux"
import { isAutenticade, isNoAutenticade } from "../../store/auth/authSlice";
import { controlAnimalApi } from "../../api";
import { isLoginUser, onErrorLogin } from "../../store/user/userSlice";

export const useAuthStore = () => {

    const dispatch = useDispatch();

    const {
        autenticaded,        
    } = useSelector( state => state.auth);

    const {
        errorMessage,
    } = useSelector(state => state.user);

    /**
     * este metodo se encarga de actualizar el estado de la atenticacion
     */
    const inAutenticade = () => {
    
        dispatch(isAutenticade());
    }

    const startLogin = async ({email, password}) => {

        try {

            const {data} = await controlAnimalApi.post('/auth/login',{ email,password });
            
            // guardamos el token el local storage
            localStorage.setItem('token', data.token);
            localStorage.setItem('token-ini-date', new Date().getTime());

            dispatch( isLoginUser({id_user: data.id_user, email: data.email, finca: data.finca}))

            dispatch( isAutenticade());
            
        } catch (error) {
            
            console.log(error);
            dispatch(onErrorLogin('Credenciales incorrectas'));
            // setTimeout(() => {
            //     dispatch(onErrorLogin('')); 
            // }, 10)

        }
     
    }

    const checkAuthToken = async() => {
        const token = localStorage.getItem('token');

        if (!token) return dispatch(isNoAutenticade());

        try {
            
            const {data} = await controlAnimalApi.get('/auth/refres');
          
            localStorage.setItem('token', data.token);
            localStorage.setItem('token-ini-date', new Date().getTime());
            dispatch( isLoginUser({id_user: data.id_user, email: data.email, finca: data.finca}))
            dispatch( isAutenticade());
            

        } catch (error) {
            console.log(error)
            dispatch(isNoAutenticade());
        }
    }

    return {
        autenticaded,
        inAutenticade,
        startLogin,
        errorMessage,
        checkAuthToken,
    }


}