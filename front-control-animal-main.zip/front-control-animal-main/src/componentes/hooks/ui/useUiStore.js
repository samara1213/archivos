import { useDispatch, useSelector } from "react-redux"
import { isCloseModalCreateFinca, isOpenModalCreateFinca } from "../../store";

export const useUiStore = () => {

    const dispatch = useDispatch();

    const {
        openModalCreateFinca,        
    } = useSelector(state => state.ui);

    const modalCreateFincaOpen = () => {

        dispatch(isOpenModalCreateFinca());
    }

    const modalCreateFincaClose = () => {

        dispatch(isCloseModalCreateFinca());
    }

    return {
        openModalCreateFinca,
        modalCreateFincaOpen,
        modalCreateFincaClose,
    }

}