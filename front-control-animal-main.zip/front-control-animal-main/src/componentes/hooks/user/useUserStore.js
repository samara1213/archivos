import { useSelector } from "react-redux"

export const useUserStore = () => {


    const {
        dataUser
    } = useSelector( state => state.user);

    return {
        dataUser,
    }


}