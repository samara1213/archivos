
import { Link as routerLink } from 'react-router-dom';
import { Alert, Button, Grid, Link, TextField, Typography } from "@mui/material"
import { AuthLayouth } from '../layout/AuthLayouth';
import { useAuthStore, useForm } from '../../hooks';
import { useEffect, useState } from 'react';


export const LoginPage = () => {

    let error = "verifique los datos ingresados";

    const {autenticaded,inAutenticade, startLogin, errorMessage} = useAuthStore();

    const [formSubmid, setformSubmid] = useState(false);
    const [errorField, seterrorField] = useState('')


    const {email, password, formState, onInputChange } = useForm({
        email: '',
        password: '',
    });

    const onSubmit = (event) => {
        
        event.preventDefault();

        // se inicia la peticion al back
        startLogin({email, password}); 
 

        //inAutenticade();
        console.log(formState)
    }

    useEffect(() => {        

        if (errorMessage !== '') {

            seterrorField(errorMessage);
            setformSubmid(true);
        }   
   
    }, [errorMessage])
        
    return (
        <>
            <AuthLayouth title="Login">
                <form onSubmit={ onSubmit }>
                    <Grid container>
                        <Grid item xs={12} sx={{ mt: 2 }}>

                         {(formSubmid) ?
                          <Alert severity="error" sx={{mb:2}}>{`${errorField}`}</Alert>
                          : null
                         }                        
                            <TextField
                                label="Correo"
                                type="email"
                                name='email'
                                value={formState.email}
                                placeholder="Ingresa tu correo"
                                fullWidth
                                onChange={onInputChange}
                            />
                        </Grid>
                        <Grid item xs={12} sx={{ mt: 2 }}>
                            <TextField
                                label="Contraseña"
                                type="password"
                                name='password'
                                value={formState.password}
                                placeholder="Ingresa tu contraseña"
                                fullWidth
                                onChange={onInputChange}
                            />
                        </Grid>
                        <Grid item xs={12} sx={{ mt: 2 }}>
                            <Button variant="contained"
                                fullWidth
                                sx={{ backgroundColor: 'green' }}                                
                                type='submit'
                                
                            >
                                <Typography sx={{ color: 'white' }}> Ingresar</Typography>
                            </Button>
                        </Grid>
                        <Grid container direction='row' justifyContent='end'>
                            <Link component={routerLink} to="/auth/recoverdPassword">
                                Olvide mi contraseña
                            </Link>

                        </Grid>
                    </Grid>
                </form>
            </AuthLayouth>
        </>
    )
}