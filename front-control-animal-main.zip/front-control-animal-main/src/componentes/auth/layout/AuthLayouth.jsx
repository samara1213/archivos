import { Grid, Typography } from "@mui/material"


export const AuthLayouth = ({ children, title = ''}) => {
    return (
        <>
            <Grid container
                spacing={0}
                direction="column"
                alignItems="center"
                justifyContent="center"
                sx={{ minHeight: '100vh', backgroundColor: 'primary.main', Padding: 4 }}
            >

                <Grid item
                    xs={3}
                    sx={{
                        borderRadius: 2,
                        backgroundColor: 'white',
                        padding: 3,
                        width: { sm: 450 }
                    }}
                >
                    <Typography variant="h5" sx={{ mb: 1}}> {title} </Typography>

                    {children}

                </Grid>
            </Grid>

        </>
    )
}

