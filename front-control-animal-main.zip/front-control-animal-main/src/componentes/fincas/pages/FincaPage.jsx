import { Box, Button, Grid, IconButton, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Typography } from "@mui/material"
import { SideNav } from "../../sidenav/SideNav"
import { getFincasDB } from "../../services"
import { useEffect, useState } from "react"
import { AddBoxOutlined, EditOutlined } from "@mui/icons-material";
import { ModalCreateFinca } from "./ModalCreateFinca";
import { useUiStore } from "../../hooks";
import { ModalEditarFinca } from "./ModalEditarFinca";
import { DataGrid, } from "@mui/x-data-grid";
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css'

// const columns = [
//   {
//     id:        'ID', 
//     name:      'NOMBRE EMPRESA',
//     nit:       'NIT EMPRESA',
//     direccion: 'DIRECCION',
//     telefono:  'TELEFONO',
//     edit:      'EDITAR'
//   }

// ];



export const FincaPage = () => {

  const columns = [

    { field: 'nit_finc', headerName: 'NIT', width: 150 },
    { field: 'nombre_finc', headerName: 'NOMBRE', width: 300},
    { field: 'direccion_finc', headerName: 'DIRECCION', width: 110},
    { field: 'telefono_finc', headerName: 'TELEFONO', width: 110},
    { field: 'contacto_finc', headerName: 'CONTACTO', width: 150},
    { field: 'edit', headerName: 'EDITAR',
      renderCell: (params) => (        
       <IconButton onClick={() => dataRegistro(params.row)}>
       <EditOutlined />
      </IconButton>
      ),  
    }, 
  
  ];

  const [fincas, setfincas] = useState([]);
  const { modalCreateFincaOpen } = useUiStore();
  const [editFinca, setEditFinca] = useState({});
  const [typeModal, setTypeModal] = useState(0);

  /**
   * metodo que llama el servicio del api para obtener el listado de fincas
   */
  const getFincas = async () => {

    try {

      const respuesta = await getFincasDB();
         
      const lstFincas = respuesta.data.map((itemFinca) => ({
        id_finc:       itemFinca.id_finc,
        nit_finc:       itemFinca.nit_finc,
        nombre_finc:    itemFinca.nombre_finc,
        direccion_finc: itemFinca.direccion_finc,
        telefono_finc:  itemFinca.telefono_finc,
        contacto_finc:  itemFinca.contacto_finc,
      }));

      setfincas(lstFincas);
      
    } catch (error) {
      
      console.log("********ERROR EN CONSULTA FINCAS");
      console.log(error);

      Swal.fire('Fincas', '!Ohs se presento un error', 'error');
    }

  }

  // use efect para cargar los datos de las empresa
  useEffect(() => {

    getFincas();
     
  }, []);
  

  /**
   * constante con los estilos d ela tabla basica
   */
  const headerCellStyle = {
    backgroundColor: 'black', // Color de fondo de la cabecera
    color: 'white', // Color del texto de la cabecera
    fontWeight: 'bold', // Estilo de fuente en negrita
  };

  /**
   * funcion para abrir el modal de crear
   */
  const openModalCreate = () => {

     modalCreateFincaOpen();
     setTypeModal(1);
  }

  /**
   * funcion para abrir el modal de editar
   */
  const openModalEdit = () => {

    modalCreateFincaOpen();
    setTypeModal(2);
 }

 /**
  * metodo para ontener el registro seleccionado
  * @param {} registro seleccionado 
  */
  const dataRegistro = (registro) => {

    setEditFinca(registro);
    openModalEdit();

  }

  /**
   * metodo para obtener el id unico para la tabla 
   * @param {*} fila 
   * @returns 
   */
  const getRowId = (fila) => fila.nit_finc;
  return (
    <>    
    <Box sx={{ display: 'flex'}}>
        <SideNav/>
        <Box component="main" sx={{ flexGrow: 1, p: 8}}>
          <Grid container sx={{mt:5}}>
            <Typography variant="h6" sx={{mb:4}}>
              Administracion Fincas
            </Typography>
            <Grid container>
              <Button variant="contained" sx={{mb:2, alignItems:'left'}}
                startIcon={<AddBoxOutlined></AddBoxOutlined>}
                onClick={openModalCreate}
              >
                Crear
              </Button>
            </Grid>
 
            <Grid item>
              {/* <TableContainer>
                <Table sx={{ width: '100%' }} aria-label="simple table">
                  <TableHead sx={{backgroundColor:'black'}}>
                    {columns.map((colum) => (
                      <TableRow
                       key={colum.id}                      
                      >
                        <TableCell sx={{color:'white'}}>{colum.nit}</TableCell>
                        <TableCell sx={{color:'white'}}>{colum.name}</TableCell>
                        <TableCell sx={{color:'white'}}>{colum.direccion}</TableCell>
                        <TableCell sx={{color:'white'}}>{colum.telefono}</TableCell>
                        <TableCell sx={{color:'white'}}>{colum.edit}</TableCell>
                      </TableRow>
                    ))}
                  </TableHead>
                  <TableBody>
                    {
                      fincas.map((finca) => (
                        <TableRow
                         key={finca.id_finc}
                        >
                          <TableCell align="left">{finca.nit_finc}</TableCell>
                          <TableCell align="left">{finca.nombre_finc}</TableCell>
                          <TableCell align="left">{finca.direccion_finc}</TableCell>
                          <TableCell align="left">{finca.telefono_finc}</TableCell>
                          <TableCell align="center">
                            <Button onClick={() => dataRegistro(finca)}>
                              <EditOutlined></EditOutlined>
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    }
                  </TableBody>
                </Table>
              </TableContainer>           
            */}
            </Grid>
          </Grid>
          <div style={{ height: 400, width: '100%' }}>
            <DataGrid              
              rows={fincas}
              columns={columns}
              getRowId={getRowId}
              initialState={{
                pagination: {
                  paginationModel: { page: 0, pageSize: 5 },
                },
              }}
              pageSizeOptions={[5, 10]}
              
            />
            </div> 
        </Box>
    </Box>
    <ModalCreateFinca actualizarTabla={getFincas} typeModal={typeModal} />
    <ModalEditarFinca actualizarTabla={getFincas} dataFinca={editFinca} typeModal={typeModal} />
    </>
  )
}
