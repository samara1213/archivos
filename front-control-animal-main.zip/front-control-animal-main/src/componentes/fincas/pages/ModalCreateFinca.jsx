
import { Button, Grid, TextField, Typography } from '@mui/material';
import Modal from 'react-modal';
import { useForm, useUiStore } from '../../hooks';
import { CloseOutlined, SaveAsOutlined } from '@mui/icons-material';
import { createFincaDB } from '../../services';
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css'

const customStyles = {
    content: {
      top: '50%',
      left: '60%',
      right: 'auto',
      bottom: 'auto',
      marginRight: 'auto',
      transform: 'translate(-50%, -50%)',
    },
  };
  Modal.setAppElement('#root');

export const ModalCreateFinca = ({actualizarTabla, typeModal}) => {

    const { openModalCreateFinca, modalCreateFincaClose } = useUiStore();
    const { formState, onInputChange} = useForm({
        nit: '',
        name: '',
        telefono: '',
        direccion: '',
        contacto: '',
    });

    const closeModal = () => {

        modalCreateFincaClose();
    }

    const createFinca = async(data) => {

        try {
            
            const obj = {
                nombre_finc: data.name,
                nit_finc: data.nit,
                direccion_finc: data.direccion,
                telefono_finc: data.telefono,
                contacto_finc: data.contacto,
              
              }      
            await createFincaDB(obj);
            
            // mensaje de confirmacion
            Swal.fire('Fincas', 'Se agrego correctamente la data', 'success');

            // se actualiza la tabla con los registro insertado
            actualizarTabla();
            
        } catch (error) {
            
            console.log("******* ERROR CREANDO EMPRESA");
            console.log(error);

            // mensaje de confirmacion
            Swal.fire('Fincas', '!Ohs se presento un error', 'error');
        }
    }
    const onSubmit = (event) => {
        
        event.preventDefault();

        // se envia a crear la finca
        createFinca(formState);
        
        modalCreateFincaClose();
    }


  return (
    <>
    <Modal
        isOpen={typeModal === 1 ? openModalCreateFinca : false}
        style={customStyles}
        onRequestClose={closeModal}        
    >
        <Typography variant='h5' sx={{mb:2}}>
            Crear nueva finca
        </Typography>
        <form onSubmit={ onSubmit }>
            <Grid container >
                <Grid item xs={12} sm={9} md={5} lg={12} xl={4} sx={{m:1}}>
                    <TextField
                        label="Nit"
                        type="text"
                        name='nit'
                        value={formState.nit}
                        placeholder="Ingresa numero de nit"
                        fullWidth
                        onChange={onInputChange}
                    />
                </Grid>
                <Grid item xs={12} sm={9} md={5} lg={12} xl={4} sx={{m:1}}>
                    <TextField
                        label="Nombre"
                        type="text"
                        name='name'
                        value={formState.name}
                        placeholder="Ingresa Nombre de la finca"
                        fullWidth
                        onChange={onInputChange}
                    />
                </Grid>
                <Grid item xs={12} sm={9} md={5} lg={12} xl={4} sx={{m:1}}>
                    <TextField
                        label="telefono"
                        type="text"
                        name='telefono'
                        value={formState.telefono}
                        placeholder="Ingresa telefono de la finca"
                        fullWidth
                        onChange={onInputChange}
                    />
                </Grid>
                <Grid item xs={12} sm={9} md={5} lg={12} xl={4} sx={{m:1}}>
                    <TextField
                        label="Direccion"
                        type="text"
                        name='direccion'
                        value={formState.direccion}
                        placeholder="Ingresa direccion de la finca"
                        fullWidth
                        onChange={onInputChange}
                    />
                </Grid>
                <Grid item xs={12} sm={9} md={5} lg={12} xl={4} sx={{m:1}}>
                    <TextField
                        label="Contacto"
                        type="text"
                        name='contacto'
                        value={formState.contacto}
                        placeholder="Ingresa contacto de la finca"
                        fullWidth
                        onChange={onInputChange}
                    />
                </Grid>
            </Grid>
            <Grid container>
                <Grid item xs={12} sm={9} md={5} lg={12} xl={4} sx={{m:1}}>                    
                    <Button variant="contained"                         
                            type='submit'
                            startIcon={<SaveAsOutlined></SaveAsOutlined>}
                            sx={{m:2}}                                
                    >
                    <Typography sx={{ color: 'white' }}> guardar</Typography>
                    </Button>
                    <Button variant="contained"
                            startIcon={<CloseOutlined></CloseOutlined>}
                            sx={{m:2, backgroundColor:'red'}}
                            onClick={closeModal}
                    >
                    <Typography sx={{ color: 'white' }}> Cancelar</Typography>
                    </Button>
                </Grid>
            </Grid>
        </form>     
    </Modal>
    </>

  )
}
