
import { Button, Grid, TextField, Typography } from '@mui/material';
import Modal from 'react-modal';
import { useForm, useUiStore } from '../../hooks';
import { CloseOutlined, SaveAsOutlined } from '@mui/icons-material';
import { createClasiAninalDB, createFincaDB } from '../../services';
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css'

const customStyles = {
    content: {
      top: '50%',
      left: '60%',
      right: 'auto',
      bottom: 'auto',
      marginRight: 'auto',
      transform: 'translate(-50%, -50%)',
    },
  };
  Modal.setAppElement('#root');

export const ModalCreateClasificacionAnimal = ({actualizarTabla, typeModal}) => {

    const { openModalCreateFinca, modalCreateFincaClose } = useUiStore();
    const { formState, onInputChange} = useForm({        
        name: '',
    });

    const closeModal = () => {

        modalCreateFincaClose();
    }

    const createClasificacion = async(data) => {

        try {
            
            const obj = {
                nombre_clas: data.name,
              
              }      
            await createClasiAninalDB(obj);
            
            // mensaje de confirmacion
            Swal.fire('Clasificacion Animal', 'Se agrego correctamente la data', 'success');

            // se actualiza la tabla con los registro insertado
            actualizarTabla();
            
        } catch (error) {
            
            console.log("******* ERROR CREANDO CLASIFICACION ANIMAL");
            console.log(error);

            // mensaje de confirmacion
            Swal.fire('Clasificacion Animal', '!Ohs se presento un error', 'error');
        }
    }
    const onSubmit = (event) => {
        
        event.preventDefault();

        // se envia a crear la clasificacion animal
        createClasificacion(formState);
        
        modalCreateFincaClose();
    }


  return (
    <>
    <Modal
        isOpen={typeModal === 1 ? openModalCreateFinca : false}
        style={customStyles}
        onRequestClose={closeModal}        
    >
        <Typography variant='h5' sx={{mb:2}}>
            Crear nueva clasificacion
        </Typography>
        <form onSubmit={ onSubmit }>
            <Grid container >
                <Grid item xs={12} sm={9} md={5} lg={12} xl={4} sx={{m:1}}>
                    <TextField
                        label="Name"
                        type="text"
                        name='name'
                        value={formState.name}
                        placeholder="Ingresa nombre para la clasificacion"
                        fullWidth
                        onChange={onInputChange}
                    />
                </Grid> 
            </Grid>
            <Grid container>
                <Grid item xs={12} sm={9} md={5} lg={12} xl={4} sx={{m:1}}>                    
                    <Button variant="contained"                         
                            type='submit'
                            startIcon={<SaveAsOutlined></SaveAsOutlined>}
                            sx={{m:2}}                                
                    >
                    <Typography sx={{ color: 'white' }}> guardar</Typography>
                    </Button>
                    <Button variant="contained"
                            startIcon={<CloseOutlined></CloseOutlined>}
                            sx={{m:2, backgroundColor:'red'}}
                            onClick={closeModal}
                    >
                    <Typography sx={{ color: 'white' }}> Cancelar</Typography>
                    </Button>
                </Grid>
            </Grid>
        </form>     
    </Modal>
    </>

  )
}
