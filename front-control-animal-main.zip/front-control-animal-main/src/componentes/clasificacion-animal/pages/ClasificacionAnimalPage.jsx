import { Box, Button, Grid, IconButton, Typography } from "@mui/material"
import { SideNav } from "../../sidenav/SideNav"
import { AddBoxOutlined, EditOutlined } from "@mui/icons-material"
import { DataGrid } from "@mui/x-data-grid"
import { getClasificacionAnimalDB } from "../../services"
import { useEffect } from "react"
import { useState } from "react"
import { useUiStore } from "../../hooks"
import { ModalCreateClasificacionAnimal } from "./ModalCreateClasificacionAnimal"
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css'
import { ModalEditClasificacionAnimal } from "./ModalEditClasificacionAnimal"

export const ClasificacionAnimalPage = () => {

    const columns = [

        { field: 'id_clas', headerName: 'ID', width: 350 },
        { field: 'nombre_clas', headerName: 'NOMBRE CLASIFICACION', width: 300},
        { field: 'edit', headerName: 'EDITAR',
          renderCell: (params) => (        
           <IconButton onClick={() => dataRegistro(params.row)}>
           <EditOutlined />
          </IconButton>
          ),  
        }, 
      
      ];

      const [clasAnimal, setclasAnimal] = useState([]);
      const { modalCreateFincaOpen } = useUiStore();
      const [editClasif, seteditClasif] = useState({})
      const [typeModal, setTypeModal] = useState(0);

      const getClasificacionAnimal = async () => {

        try {
            
            const respuesta = await getClasificacionAnimalDB();
            
            setclasAnimal(respuesta.data);

            
        } catch (error) {

            console.log("############# ERROR LISTANDO  CLASIFICACIONES #############");
            console.log(error);
            Swal.fire('Clasificacion Animal', '!Ohs se presento un error', 'error');
            
        }
      }

      // funcion para listar las diferentes clasificaciones animales
      useEffect(() => {

        getClasificacionAnimal();  
     
      }, []);
    
   /**
   * funcion para abrir el modal de crear
   */
  const openModalCreate = () => {

    modalCreateFincaOpen();
    setTypeModal(1);
 }
   /**
   * funcion para abrir el modal de editar
   */
  const openModalEdit = () => {

    modalCreateFincaOpen();
    setTypeModal(2);
 }
  
  /**
  * metodo para ontener el registro seleccionado
  * @param {} registro seleccionado 
  */
  const dataRegistro = (registro) => {
    console.log(registro)

    seteditClasif(registro);
    openModalEdit();

  }
    
    const getRowId = (fila) => fila.id_clas;

  return (
    <>
        <Box sx={{ display: 'flex'}}>
            <SideNav />
            <Box component="main" sx={{ flexGrow: 1, p: 8}}>
                <Grid container sx={{mt:5}}>
                    <Typography variant="h6" sx={{mb:4}}>
                        Clasificacion Animal
                    </Typography>
                    <Grid container>
                        <Button
                        startIcon={<AddBoxOutlined></AddBoxOutlined>}
                        onClick={openModalCreate}
                        >
                        Agregar Nuevo
                        </Button>
                    </Grid>
                    <Grid item>               
                        <DataGrid
                            sx={{height:'auto', width:'100%', mt:2}}
                            columns={columns}
                            rows={clasAnimal}
                            getRowId={getRowId}
                            initialState={{
                                pagination: {
                                paginationModel: { page: 0, pageSize: 5 },
                                },
                            }}
                            pageSizeOptions={[5, 10]}
                        >

                        </DataGrid>
                    </Grid>
                </Grid>
            </Box>
        </Box>
        <ModalCreateClasificacionAnimal actualizarTabla={getClasificacionAnimal} typeModal={typeModal}/>
        <ModalEditClasificacionAnimal actualizarTabla={getClasificacionAnimal} dataClasAn={editClasif} typeModal={typeModal}/>
    </>
  )
}
