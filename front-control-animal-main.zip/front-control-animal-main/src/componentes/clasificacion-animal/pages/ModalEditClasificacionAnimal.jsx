
import { Button, Grid, TextField, Typography } from '@mui/material';
import Modal from 'react-modal';
import { useForm, useUiStore } from '../../hooks';
import { CloseOutlined, SaveAsOutlined } from '@mui/icons-material';
import { updateClasiAnimalDB } from '../../services';
import Swal from 'sweetalert2';
import 'sweetalert2/dist/sweetalert2.min.css'
import { useEffect } from 'react';

const customStyles = {
    content: {
      top: '50%',
      left: '60%',
      right: 'auto',
      bottom: 'auto',
      marginRight: 'auto',
      transform: 'translate(-50%, -50%)',
    },
  };
  Modal.setAppElement('#root');

export const ModalEditClasificacionAnimal = ({actualizarTabla, dataClasAn, typeModal}) => {

    const { openModalCreateFinca, modalCreateFincaClose } = useUiStore();
    const { formState, onInputChange, setformState} = useForm({        
        name: '',
    });

    const closeModal = () => {

        modalCreateFincaClose();
    }

    useEffect(() => {
    
        if(openModalCreateFinca) {
            setformState({
                name: dataClasAn.nombre_clas,
            });

        }
    }, [openModalCreateFinca])
    

    const updateClasificacion = async(data) => {

        try {
            
            const obj = {
                nombre_clas: data.name,
              
              }      
            await updateClasiAnimalDB(dataClasAn.id_clas, obj);
            
            // mensaje de confirmacion
            Swal.fire('Clasificacion Animal', 'Se actualizo la data', 'success');

            // se actualiza la tabla con los registro insertado
            actualizarTabla();
            
        } catch (error) {
            
            console.log("******* ERROR ACTUALIZANDO CLASIFICACION ANIMAL");
            console.log(error);

            // mensaje de confirmacion
            Swal.fire('Clasificacion Animal', '!Ohs se presento un error', 'error');
        }
    }
    const onSubmit = (event) => {
        
        event.preventDefault();

        // se envia a crear la clasificacion animal
        updateClasificacion(formState);
        
        modalCreateFincaClose();
    }


  return (
    <>
    <Modal
        isOpen={typeModal === 2 ? openModalCreateFinca : false}
        style={customStyles}
        onRequestClose={closeModal}        
    >
        <Typography variant='h5' sx={{mb:2}}>
            Editar clasificacion
        </Typography>
        <form onSubmit={ onSubmit }>
            <Grid container >
                <Grid item xs={12} sm={9} md={5} lg={12} xl={4} sx={{m:1}}>
                    <TextField
                        label="Name"
                        type="text"
                        name='name'
                        value={formState.name}
                        placeholder="Ingresa nombre para la clasificacion"
                        fullWidth
                        onChange={onInputChange}
                    />
                </Grid> 
            </Grid>
            <Grid container>
                <Grid item xs={12} sm={9} md={5} lg={12} xl={4} sx={{m:1}}>                    
                    <Button variant="contained"                         
                            type='submit'
                            startIcon={<SaveAsOutlined></SaveAsOutlined>}
                            sx={{m:2}}                                
                    >
                    <Typography sx={{ color: 'white' }}> guardar</Typography>
                    </Button>
                    <Button variant="contained"
                            startIcon={<CloseOutlined></CloseOutlined>}
                            sx={{m:2, backgroundColor:'red'}}
                            onClick={closeModal}
                    >
                    <Typography sx={{ color: 'white' }}> Cancelar</Typography>
                    </Button>
                </Grid>
            </Grid>
        </form>     
    </Modal>
    </>

  )
}
