

import axios from 'axios';
import { getEnvVariables } from '../helpers/getEnvVariables';


const { VITE_URL_API } = getEnvVariables();

const controlAnimalApi = axios.create({

    baseURL: VITE_URL_API
})

// Todo: configurar interceptores
controlAnimalApi.interceptors.request.use( config => {

    config.headers = {
        ...config.headers,
        'Authorization': `Bearer ${localStorage.getItem('token')}`,
    }

    return config;
})

export default controlAnimalApi;