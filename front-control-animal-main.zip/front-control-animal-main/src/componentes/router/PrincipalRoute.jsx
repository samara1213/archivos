import { Navigate, Route, Routes } from "react-router-dom"
import { FincaPage } from "../fincas/pages/FincaPage"
import { Home } from "../home/Home"
import { ClasificacionAnimalPage } from "../clasificacion-animal/pages/ClasificacionAnimalPage"
import { RazasPage } from "../razas/pages/RazasPage"


export const PrincipalRoute = () => {
  return (
    <>
        <Routes>
            <Route path="/" element={ <Home /> } />
            <Route path="/fincas" element={ <FincaPage /> } />
            <Route path="/clas-animal" element={ <ClasificacionAnimalPage /> } />
            <Route path="/razas" element={ <RazasPage /> } />
            <Route path="/*" element={ <Navigate to="/" /> }/> 
        </Routes>      
    </>
  )
}
