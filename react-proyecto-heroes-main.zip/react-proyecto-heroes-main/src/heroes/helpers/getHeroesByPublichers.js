import { heroes } from "../data/heroes";

export const getHeroesByPublihers = (publisher) => {

    const validPublisher = ['DC Comics', 'Marvel Comics']

    if (!validPublisher.includes(publisher)) {

        throw new Error(' No encontramos data para visualizar');
    }

    return heroes.filter(heroe => heroe.publisher === publisher)
}