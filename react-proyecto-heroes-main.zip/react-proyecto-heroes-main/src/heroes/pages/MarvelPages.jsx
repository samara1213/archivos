import React from 'react'
import { HeroesLists } from '../components/HeroesLists'

export const MarvelPages = () => {
  return (
    <>
    <h1>Marvel Comics</h1>
    <hr />
    <HeroesLists publisher={'Marvel Comics'}/>

    </>
  )
}
