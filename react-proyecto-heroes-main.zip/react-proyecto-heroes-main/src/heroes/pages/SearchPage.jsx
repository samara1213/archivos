import { useLocation, useNavigate } from "react-router-dom";
import { useForm } from "../../hooks/useForm";
import queryStrimg from "query-string";
import { Hero } from "./Hero"
import { getHeroByName } from "../helpers/getHeroByName";
import { HeroesItems } from "../components/HeroesItems";

export const SearchPage = () => {
  
  const navigate  = useNavigate();
  const location = useLocation(); // para obtener la localizacion del html

  // para obtener elqueryparametro de la url
  const {q =''} = queryStrimg.parse(location.search);

  const lstHeroes = getHeroByName(q);
  
  const { searchText, onInputChange} = useForm({
    searchText: '',
  });

  // esto es para evitar que se lance el formulario varias veces
  const onSeaarchSubmit = (event) => { 

    event.preventDefault();

    if (searchText.trim().length <= 1) return;
    navigate(`?q=${searchText.toLocaleLowerCase().trim()}`);
  }
  
  return (
    <>
    <h1>Search</h1>
    <hr />
    <div className="row">
    <div className="col-5">  
    <h4>Searching</h4>
    <hr />
    <form onSubmit={onSeaarchSubmit}>
      <input 
      type="text"
      placeholder="Ingrese heroe" 
      className="form-control"
      name="searchText"
      autoComplete="off"
      value={searchText}
      onChange={onInputChange}/>
      <button className="btn btn-success  mt-1"> Buscar</button>
    </form>
    </div>
    <div className="col-7">

      <h4>Result</h4>
      <hr />
      {
        (q ==='') 
        ?<div className="alert alert-primary"> Buscar nuevamente </div>
        : (lstHeroes.length === 0)
        && <div className="alert alert-danger"> no existe data para:  {q}</div>
      }
      
      

      {

          lstHeroes.map(heroe => (
          <HeroesItems key={heroe.id}
          heroe={heroe} />
        ))

      }      


     </div>
    </div>
    </>
  )
}
