import { React, useMemo } from 'react'
import { Navigate, useNavigate, useParams } from 'react-router-dom'
import { getHeroById } from '../helpers/getHeroBy';

export const Hero = () => {
  
  const navigate = useNavigate();
  // de esta forma se obtine el valor del parametro de la url
  {
    /**
     * en la url queda asi ruta/:heroId
     * y para obtener el parametro se utiliza useParams();
     * const {heroId, ...rest} = useParams();
    */
  }
  const {heroId, ...rest} = useParams();

  // useMeno se utiliza para grabar una funcion y que no se vuleva a disparar solo hasta
  // que cambie el valor del parametro en este caso seria el heroId
  const hero = useMemo( () => getHeroById(heroId),[heroId]); 
  
  const urlImage = `/src/assets/heroes/${hero.id}.jpg`;
 
  const onRegreset = () => {

    // de esta manera se regresa a la pagina anterior del historial
    navigate(-1);
  }
  if(!hero) {
    return <Navigate to={"/"}/>
  }

  return (
    <div className=' row mt-5 animate__animated animate__bounce'>
      <div className="col-4">
        <img 
        src={urlImage}
        alt={hero.superhero}
        className='img-thumbnail'
        />
      </div>
      <div className="col-8">
       <div className="card-body">
        <h5 className='card-title'>{hero.superhero}</h5>
        <p className='card-text'> {hero.alter_ego} </p>
        <p className='card-text'> {hero.characters} </p>
        <button 
          onClick={onRegreset}
          className='btn btn-primary'>
          Regresar
        </button>
       </div>
       </div> 

    </div>
  )
}
