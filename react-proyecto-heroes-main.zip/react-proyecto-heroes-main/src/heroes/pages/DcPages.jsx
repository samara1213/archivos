import React from 'react'
import { HeroesLists } from '../components/HeroesLists'

export const DcPages = () => {
  return (
    <>
    <h1>DC Comics</h1>
    <hr />
    <HeroesLists publisher={'DC Comics'}/>

    </>
  )
}
