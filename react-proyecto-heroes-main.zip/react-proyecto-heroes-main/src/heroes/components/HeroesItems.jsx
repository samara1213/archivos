import React from 'react'
import { Link } from 'react-router-dom';

export const HeroesItems = ({ heroe }) => {
    
    const urlImage = `/src/assets/heroes/${heroe.id}.jpg`;
    return (

        <>
         <div className='col'>
            <div className='card'>
                <div className="row no-gutters">
                    <div className="col-4">
                        <img src={urlImage} className='card-img' alt={heroe.superhero}/>
                    </div>
                    <div className="col-8">
                        <div className="card-body">
                            <h5 className='card-title'>{heroe.superhero}</h5>
                            <p className='card-text'> {heroe.alter_ego} </p>
                            <p className='card-text'> {heroe.characters} </p>
                            <Link
                            to={`/hero/${heroe.id}`}
                            >
                            Mas Data..
                            </Link>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        </>
    )
}
