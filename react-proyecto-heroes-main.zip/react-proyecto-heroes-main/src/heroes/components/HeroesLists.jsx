import React, { useMemo } from 'react'
import { getHeroesByPublihers } from '../helpers/getHeroesByPublichers'
import { HeroesItems } from './HeroesItems';

export const HeroesLists = ({ publisher }) => {

    const lstHeroes = useMemo(() => getHeroesByPublihers(publisher),[publisher]);

    return (
        <>
            <h1>{`lista de ${publisher}`}</h1>

            <div className="row rows-cols-1 row-cols-md-3  g-3">
                {
                    lstHeroes.map(heroe => (
                        <HeroesItems key={heroe.id}
                            heroe={heroe} />
                    ))
                }
            </div>

        </>
    )
}
