import { Navbar } from "../../ui/components/Navbar"
import { Routes, Route, Navigate, Link } from "react-router-dom";
import { MarvelPages } from "../pages/MarvelPages";
import { DcPages } from "../pages/DcPages";
import { SearchPage } from "../pages/SearchPage";
import { Hero } from "../pages/Hero";

export const HeroesRoutes = () => {
  return (
    <>
    
        <Navbar/>
        <div className="container">
            <Routes>
                <Route path="" element={< MarvelPages/>}/>
                <Route path="dc" element={< DcPages/>}/>
                <Route path="search" element={< SearchPage/>}/>
                <Route path="hero/:heroId" element={< Hero/>}/>
            </Routes>
        </div>


    </>
  )
}
