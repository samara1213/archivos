
import { Routes, Route, Navigate, Link } from "react-router-dom";
import { MarvelPages } from "../heroes/pages/MarvelPages";
import { DcPages } from "../heroes/pages/DcPages";
import { LoginPages } from "../auth/pages/LoginPages";
import { Navbar } from "../ui/components/Navbar";
import { HeroesRoutes } from "../heroes/routes/HeroesRoutes";
import { PrivateRoutes } from "./PrivateRoutes";
import { PublicRoute } from "./PublicRoute";

export const AppRoutes = () => {
  return (
    <>
    <Routes>
      
        <Route path="/login" element={
          <PublicRoute>
              <LoginPages/>
          </PublicRoute>
        }/>

        <Route path="/*" element={
          <PrivateRoutes>
            < HeroesRoutes/>
          </PrivateRoutes>
        }/>
        
    </Routes>
    </>
  )
}
