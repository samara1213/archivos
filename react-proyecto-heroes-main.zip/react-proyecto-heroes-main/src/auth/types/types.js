

export const types = {

    login:  '[Auth] login',
    logout: '[Auth] logout',
    
}