import React from 'react'
import { AppRoutes } from './routes/AppRoutes'
import { AuthProvider } from './auth/context/AuthProvider'

export const HeroesApp = () => {
  return (
    < AuthProvider>
     <AppRoutes />
    </AuthProvider> 
  )
}
