import { BadRequestException, Injectable, InternalServerErrorException, Logger, NotFoundException } from '@nestjs/common';
import { CreateFincaDto } from './dto/create-finca.dto';
import { UpdateFincaDto } from './dto/update-finca.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Finca } from './entities/finca.entity';
import { PaginationDto } from '../common/dtos/pagination.dto';

@Injectable()
export class FincasService {

  // manejo de los log
  private readonly logger = new Logger('FincService');


  constructor(

    @InjectRepository(Finca)
    private readonly fincaRepository: Repository<Finca>,
  ) {}

  /**
   * Metodo para insertar en la base de datos una nueva empresa
   * @param createFincaDto 
   */
  async create(createFincaDto: CreateFincaDto) {

    try {

      // se crea el objecto con los registros del dto
      const finca = this.fincaRepository.create(createFincaDto);

      // se inserta en la base de datos el nuevo registro
      await this.fincaRepository.save(finca);

      return finca;
      
    } catch (error) {
      
       this.handleExceptions(error);

    }
  
   
  }

  async findAll(paginationDto: PaginationDto) {

    try {
      // se desesctrura lo que viene el el dto si no trae nada 
      // los valores por defecto son 10 y o
      const {limit = 10, offset = 0} = paginationDto;

      // de esta manera se regresan todos los registros sin enviar ningun registro
      // pero asi se regresan paginados
      return await this.fincaRepository.find({

        take: limit,// aca se toma la cantidad que viene en el limite
        skip: offset, // aca se  coloca la pagina que se quiere obtener 
        //TODO: aca se colocan la relaciones
      });
      
    } catch (error) {
      
      this.handleExceptions(error)
    }
 
  }

  async findOne(id: string) {
    
    try {
      const finca = await this.fincaRepository.findOneBy({id_finc: id});
     
      if(!finca) {

        throw new BadRequestException('La finca no existe');
      }

      return finca;
      
    } catch (error) {
      
      this.handleExceptions(error);
    }
    
  }

  async update(id: string, updateFincaDto: UpdateFincaDto) {

    // se obtiene la informacion d ela finca a actualizar y se cargan los registros nuervos 
    const finca = await this.fincaRepository.preload({

      id_finc: id,
      ...updateFincaDto
    });

    // varifico si la finca a actualizar existe
    if(!finca) throw new NotFoundException('No existe Fincas a actualizar');

    try {
      
      // se guarda la informacion de la finca
      await this.fincaRepository.save(finca);

    } catch (error) {
      
      this.handleExceptions(error);
    }

    return finca;
    
  }

  async remove(id: string) {

    try {
      const finca = await this.findOne(id);

      await this.fincaRepository.remove(finca);    
      
    } catch (error) {
      
      this.handleExceptions(error);
    }
  }

  /**
   * Metodo que se encarga de validar cualquier  tipo de error 
   * @param error generado
   */
  private handleExceptions(error: any) {

    this.logger.error(error)
    // aca se ueden validar los codigos de error 
    throw new InternalServerErrorException('Error del sistema')
  }
}
