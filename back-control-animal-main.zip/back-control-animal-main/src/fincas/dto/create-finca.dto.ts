import { IsOptional, IsString, MinLength} from "class-validator";

export class CreateFincaDto {

    @IsString()
    @MinLength(1)
    nombre_finc: string;

    @IsString()
    @IsOptional()
    nit_finc?: string;

    @IsString()
    @MinLength(1)
    direccion_finc: string;

    @IsString()
    @MinLength(1)
    telefono_finc: string;

    @IsString()
    @MinLength(1)
    contacto_finc:  string;

    

}
