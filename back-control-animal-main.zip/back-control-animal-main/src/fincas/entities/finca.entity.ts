import { Animal } from "src/animales/entities/animale.entity";
import { User } from "src/auth/entities/user.entity";
import { Column, CreateDateColumn, Entity, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

@Entity()
export class Finca {

    @PrimaryGeneratedColumn('uuid')
    id_finc: string;

    // @Column('text', {
    //     unique: true -- un ejemplo de restricciones
    // })
    @Column('text', {
        unique: true,
    })    
    nit_finc: string;
    
    @Column('text')
    nombre_finc: string;

    @Column('text')
    direccion_finc: string;

    @Column('text')
    telefono_finc: string;

    @Column('text')
    contacto_finc: string;
    
    @CreateDateColumn({type: 'timestamp'})
    creacion_finc: Date;

    @UpdateDateColumn({type: 'timestamp'}) 
    modificacion_finc: Date;


    @OneToMany(
        () => Animal,
        ( animal ) => animal.finca,
    )
    animal: Animal;

    @OneToMany(
        () => User,
        ( user ) => user.finca,
    )
    user: User;

}
