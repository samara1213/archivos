import { Module } from '@nestjs/common';
import { FincasService } from './fincas.service';
import { FincasController } from './fincas.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Finca } from './entities/finca.entity';
import { ClasificacioAnimalesModule } from 'src/clasificacio-animales/clasificacio-animales.module';

@Module({
  controllers: [FincasController],
  providers: [FincasService],
  imports: [TypeOrmModule.forFeature([Finca]),
    ClasificacioAnimalesModule,
  ],
  exports: [TypeOrmModule, FincasService]
})
export class FincasModule {}
