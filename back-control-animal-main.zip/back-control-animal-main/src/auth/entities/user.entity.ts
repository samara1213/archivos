import { Finca } from "src/fincas/entities/finca.entity";
import { BeforeInsert, BeforeUpdate, Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

@Entity('users')
export class User {

    @PrimaryGeneratedColumn('uuid')
    id_user: string;

    @Column('text')
    nombre_user: string;

    @Column('text')
    apellido_user: string;

    @Column('text',{
        unique: true,             
    }
    )
    email: string;

    @Column('text',{
        select: false,
    })
    password: string;

    @Column('bool',{
        default: true
    })
    isActive: boolean;

    @Column('text',{
        array: true,
        default: ['user']
    })
    roles: string[];

    @CreateDateColumn({type: 'timestamp'})
    creacion_user: Date;

    @UpdateDateColumn({type: 'timestamp'})
    modificacion_user: Date;

    @ManyToOne(
        () => Finca,
        (finca) => finca.user,
        {eager: true}
    )
    finca: Finca;

    @BeforeInsert()
    checkFieldBeforeInsert() {

        this.email = this.email.toLocaleLowerCase().trim();
    }

    @BeforeUpdate()
    checkFieldBeforeUpdate() {

        this.checkFieldBeforeInsert()
    }
}
