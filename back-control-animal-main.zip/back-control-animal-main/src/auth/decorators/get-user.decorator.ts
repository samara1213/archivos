
import { createParamDecorator, ExecutionContext, InternalServerErrorException } from '@nestjs/common';

/**
 * este decorador se utiliza para obtener el usuario que esta haciendo la peticion
 * del token, cuando se llama este decorador podemos obtener la data 
 * el contexto 
 */
export const GetUser = createParamDecorator(
    (data, ctx: ExecutionContext) => {
        
        const req = ctx.switchToHttp().getRequest();
        const user = req.user;
        if (!user)
            throw new InternalServerErrorException('Usuario no presente el la request')
        
        return user;
    }
);