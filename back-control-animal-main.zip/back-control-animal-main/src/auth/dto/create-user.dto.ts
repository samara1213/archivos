import { IsEmail, IsString, IsUUID, MaxLength, MinLength } from "class-validator";

export class CreateUserDto {

    @IsString()
    @MinLength(1)
    nombre_user: string;

    @IsString()
    @MinLength(1)
    apellido_user: string;

    @IsString()
    @IsEmail()
    email: string;

    @IsString()
    @MinLength(6)
    @MaxLength(50)
    password: string;

    @IsUUID()
    id_finca: string;
}