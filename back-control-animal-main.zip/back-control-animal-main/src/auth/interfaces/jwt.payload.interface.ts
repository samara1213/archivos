
export interface JwtPayload {

    email: string;

    // TODO: añadir lo que mas se quiera llevar el token
}