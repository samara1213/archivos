import { BadRequestException, Injectable, InternalServerErrorException, Logger } from '@nestjs/common';
import { Repository } from 'typeorm';
import { User } from './entities/user.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { FincasService } from 'src/fincas/fincas.service';
import * as bcrypt from 'bcrypt'
import { CreateUserDto, LoginUserDto } from './dto/';
import { JwtPayload } from './interfaces/jwt.payload.interface';
import { JwtService} from '@nestjs/jwt';


@Injectable()
export class AuthService {

  // manejo de los log
  private readonly logger = new Logger('AuthService');
  
  constructor(

    @InjectRepository(User)
    private readonly userRepository: Repository<User>,

    private readonly fincaService: FincasService,

    private readonly jwtService: JwtService,

  ){}
  
  async create(createUserDto: CreateUserDto) {
   
    try {

      const {password, ...userData} = createUserDto;

      const finca = await this.fincaService.findOne(createUserDto.id_finca);

      let user = this.userRepository.create({
        ...userData,
        password: bcrypt.hashSync(password, 10),
      });     

      user.finca = finca;

      await this.userRepository.save(user);

      delete user.password;

      return user;
      
    } catch (error) {
      
      this.handleExceptions(error);
    }
  }

  async login(loginUserDto: LoginUserDto) {
        
    const {password, email} = loginUserDto;

    const user = await this.userRepository.findOne({
      where: {email: email},
      select: {password: true, email: true, id_user: true},
    });
    
    if(!user) throw new BadRequestException('El Usuario y/o contraseña es incorrecto')

    if (!bcrypt.compareSync(password, user.password))
      throw new BadRequestException('El Usuario y/o contraseña es incorrecto')

    delete user.password;
    
    return {
      ...user,
      token: this.generateJWT({email: user.email}),
    };    

  }

  private generateJWT( paylod: JwtPayload){

    // generar un token
    const token = this.jwtService.sign( paylod);

    return token;

  }

  async refresToken(user: User) {

    return {
      ...user,
      token: this.generateJWT({email: user.email}),
    };    
  }

  /**
   * Metodo que se encarga de validar cualquier  tipo de error 
   * @param error generado
  */
  private handleExceptions(error: any): never {

    if(error.code ==='23505') throw new BadRequestException('El Usuario ya existe..');

    this.logger.error(error)
    // aca se ueden validar los codigos de error 
    throw new InternalServerErrorException('Error del sistema')
  }


}
