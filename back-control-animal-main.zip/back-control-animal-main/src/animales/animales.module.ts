import { Module } from '@nestjs/common';
import { AnimalesService } from './animales.service';
import { AnimalesController } from './animales.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Animal } from './entities/animale.entity';
import { FincasModule } from '../fincas/fincas.module';
import { ClasificacioAnimalesModule } from '../clasificacio-animales/clasificacio-animales.module';

@Module({
  controllers: [AnimalesController],
  providers: [AnimalesService],
  imports: [TypeOrmModule.forFeature([Animal]),
  FincasModule,
  ClasificacioAnimalesModule
  ],

  exports: [TypeOrmModule]
})
export class AnimalesModule {}
