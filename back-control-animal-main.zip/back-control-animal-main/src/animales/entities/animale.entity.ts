import { ClasificacioAnimal } from "src/clasificacio-animales/entities/clasificacio-animale.entity";
import { Finca } from "src/fincas/entities/finca.entity";
import { Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

@Entity()
export class Animal {

    @PrimaryGeneratedColumn('uuid')
    id_anim: string;

    @Column('text')
    nombre_anim: string;

    @Column('text')
    madre_anim: string;

    @Column('text')
    padre_anim: string;

    @Column('text')
    fecha_nacimiento_anim: Date;

    @Column('text')
    genero_anim: string

    @CreateDateColumn({type: 'timestamp'})
    creacion_anim: Date;

    @UpdateDateColumn({type: 'timestamp'})
    modificacion_anim: Date;

    @ManyToOne(
        () => Finca, 
        ( finca ) => finca.animal,
        {eager: true},
    )
    finca: Finca;

    @ManyToOne(
        () => ClasificacioAnimal,
        (clasificacionAnimal) => clasificacionAnimal.animal,
        { eager: true},
    )
    clasificacionAnimal: ClasificacioAnimal;

}
