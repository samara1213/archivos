import { IsString, IsUUID, MaxLength, MinLength } from "class-validator";

export class CreateAnimaleDto {

    @IsString()
    @MinLength(1)
    nombre_anim: string;

    @IsString()
    @MinLength(1)    
    madre_anim: string;

    @IsString()
    @MinLength(1)
    padre_anim: string;

    @IsString()
    fecha_nacimiento_anim : Date;

    @IsString()
    @MaxLength(1)
    genero_anim: string;

    @IsUUID()
    id_finca: string;

    @IsUUID()
    id_clasificacion_animal: string;
}
