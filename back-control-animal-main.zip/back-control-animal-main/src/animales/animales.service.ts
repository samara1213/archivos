import { Injectable, InternalServerErrorException, Logger } from '@nestjs/common';
import { CreateAnimaleDto } from './dto/create-animale.dto';
import { UpdateAnimaleDto } from './dto/update-animale.dto';
import { InjectRepository } from '@nestjs/typeorm';
import { Animal } from './entities/animale.entity';
import { Repository } from 'typeorm';
import { FincasService } from 'src/fincas/fincas.service';
import { ClasificacioAnimalesService } from '../clasificacio-animales/clasificacio-animales.service';

@Injectable()
export class AnimalesService {
    // manejo de los log
    private readonly logger = new Logger('AnimalService');


    constructor(
  
      @InjectRepository(Animal)
      private readonly animalRepository: Repository<Animal>,

      private readonly fincaService: FincasService,

      private readonly clasificacionAnimalService: ClasificacioAnimalesService
    ) {}

  /**
   * metodo que crea un animal en la base de datos
   * @param createAnimaleDto  Datos del animal 
   */
  async create(createAnimaleDto: CreateAnimaleDto) {
    
    try {

      // sacamos los datos del la finca a la que pertence el
      const {id_finca, id_clasificacion_animal, ...restoAnimal} = createAnimaleDto;

      // se consulta la finca
      const finca = await this.fincaService.findOne(id_finca);

      // se ontine la clasificacion del animal
      const clasificacion = await this.clasificacionAnimalService.findOne(id_clasificacion_animal);

      // se crea el objecto animal
      let animal = this.animalRepository.create(restoAnimal);

      // agrego la finca del animal
      animal.finca = finca;
      animal.clasificacionAnimal = clasificacion;

      // se gurda el registro en la base de datso
      await this.animalRepository.save(animal);

      // se regresa el animal creado
      return animal;    
      
    } catch (error) {
      
      this.handleExceptions(error);
    }
  }

  findAll() {
    return `This action returns all animales`;
  }

  findOne(id: number) {
    return `This action returns a #${id} animale`;
  }

  update(id: number, updateAnimaleDto: UpdateAnimaleDto) {
    return `This action updates a #${id} animale`;
  }

  remove(id: number) {
    return `This action removes a #${id} animale`;
  }

    /**
   * Metodo que se encarga de validar cualquier  tipo de error 
   * @param error generado
   */
    private handleExceptions(error: any) {

      this.logger.error(error);
      // aca se ueden validar los codigos de error 
      throw new InternalServerErrorException('Error del sistema');
    }
}
