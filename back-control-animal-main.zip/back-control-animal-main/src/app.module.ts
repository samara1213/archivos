import { Module } from '@nestjs/common';
import { ConfigModule } from '@nestjs/config';
import { TypeOrmModule } from '@nestjs/typeorm';
import { FincasModule } from './fincas/fincas.module';
import { CommonModule } from './common/common.module';
import { AnimalesModule } from './animales/animales.module';
import { ClasificacioAnimalesModule } from './clasificacio-animales/clasificacio-animales.module';
import { RazasModule } from './razas/razas.module';
import { TipoVacunasModule } from './tipo-vacunas/tipo-vacunas.module';
import { AuthModule } from './auth/auth.module';

@Module({
  imports: [
    ConfigModule.forRoot(),

    TypeOrmModule.forRoot({
      type:'postgres',
      host: process.env.DB_HOST,
      port: +process.env.DB_PORT,
      database: process.env.DB_NAME,
      username: process.env.DB_USER_NAME,
      password: process.env.DB_PASSWORD,
      autoLoadEntities: true,
      synchronize: true, // este no debe ir en prod
    }),

    FincasModule,

    CommonModule,

    AnimalesModule,

    ClasificacioAnimalesModule,

    RazasModule,

    TipoVacunasModule,

    AuthModule,
   ],
})
export class AppModule {}
