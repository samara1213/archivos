import { IsString, IsUUID, MaxLength, MinLength } from "class-validator";

export class CreateRazaDto {

    @IsString()
    @MinLength(1)
    @MaxLength(20)
    nombre_raza: string;

    @IsUUID()
    id_clasificacion_animal: string;
}
