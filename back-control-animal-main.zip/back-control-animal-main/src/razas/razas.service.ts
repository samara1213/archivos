import { BadRequestException, Injectable, InternalServerErrorException, Logger } from '@nestjs/common';
import { CreateRazaDto } from './dto/create-raza.dto';
import { UpdateRazaDto } from './dto/update-raza.dto';
import { Repository } from 'typeorm';
import { Raza } from './entities/raza.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { ClasificacioAnimalesService } from 'src/clasificacio-animales/clasificacio-animales.service';

@Injectable()
export class RazasService {

  // manejo de los log
  private readonly logger = new Logger('RazaService');

  constructor(

    @InjectRepository(Raza)
    private readonly razaRepository: Repository<Raza>,

    private readonly clasificacionAnimalService: ClasificacioAnimalesService,
  ){}

  async create(createRazaDto: CreateRazaDto) {
    
    try {

      // sacamos el ide de la clasificacion para consultarlo
      const {id_clasificacion_animal, ...restoRaza} = createRazaDto;

      const clasificacionAnimal = await this.clasificacionAnimalService.findOne(id_clasificacion_animal);

      let raza = this.razaRepository.create(restoRaza);

      raza.clasificacionAnimal = clasificacionAnimal;

      await this.razaRepository.save(raza);

      return raza;      
      
    } catch (error) {
      
      this.handleExceptions(error);
    }
  }

  async findAll() {
    
    try {

      return await this.razaRepository.find();
      
    } catch (error) {
      
      this.handleExceptions(error);
    }
  }

  async findOne(id: string) {
    
    try {

      const raza = await this.razaRepository.findOneBy({
        id_raza: id,
      });

      if(!raza) {

        throw new BadRequestException('La raza del animal a buscar no existe');
      }

      return raza;
      
    } catch (error) {
      
      this.handleExceptions(error);
    }
  }

  async update(id: string, updateRazaDto: UpdateRazaDto) {
    
    let raza = await this.razaRepository.preload({
      id_raza: id,
      ...updateRazaDto,
    });
    
    if (!raza) throw new BadRequestException('El registro a actualizar no existe');

    try {

      const clasificacionAnimal = await this.clasificacionAnimalService.findOne(updateRazaDto.id_clasificacion_animal);

      raza.clasificacionAnimal = clasificacionAnimal;
      
      await this.razaRepository.save(raza);
      
      return raza;

    } catch (error) {
      
      this.handleExceptions(error);
    }
  }

  /**
   * Metodo que se encarga de validar cualquier  tipo de error 
   * @param error generado
   */
    private handleExceptions(error: any) {

      this.logger.error(error)
      // aca se ueden validar los codigos de error 
      throw new InternalServerErrorException('Error del sistema')
    }
}
