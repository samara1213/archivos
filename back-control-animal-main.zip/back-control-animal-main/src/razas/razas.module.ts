import { Module } from '@nestjs/common';
import { RazasService } from './razas.service';
import { RazasController } from './razas.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { Raza } from './entities/raza.entity';
import { ClasificacioAnimalesModule } from 'src/clasificacio-animales/clasificacio-animales.module';

@Module({
  controllers: [RazasController],
  providers: [RazasService],
  imports: [TypeOrmModule.forFeature([Raza]),
  ClasificacioAnimalesModule,
  ],
  exports: [
    TypeOrmModule
  ]
})
export class RazasModule {}
