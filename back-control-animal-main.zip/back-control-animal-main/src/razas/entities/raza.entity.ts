import { ClasificacioAnimal } from "../../clasificacio-animales/entities/clasificacio-animale.entity";
import { Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

@Entity()
export class Raza {

    @PrimaryGeneratedColumn('uuid')
    id_raza: string;

    @Column('text')
    nombre_raza: string;

    @CreateDateColumn({type: 'timestamp'})
    creacion_raza: Date;

    @UpdateDateColumn({type: 'timestamp'})
    modificacion_raza: Date;

    @ManyToOne(
        () =>ClasificacioAnimal, 
        ( clasificacionAnimal ) => clasificacionAnimal.raza,
        {eager: true},
    )
    clasificacionAnimal: ClasificacioAnimal;
}
