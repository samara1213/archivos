import { IsString, MaxLength, MinLength } from "class-validator";

export class CreateClasificacioAnimaleDto {

    @IsString()
    @MinLength(1)
    @MaxLength(20)
    nombre_clas: string;
}
