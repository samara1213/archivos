import { PartialType } from '@nestjs/mapped-types';
import { CreateClasificacioAnimaleDto } from './create-clasificacio-animale.dto';

export class UpdateClasificacioAnimaleDto extends PartialType(CreateClasificacioAnimaleDto) {}
