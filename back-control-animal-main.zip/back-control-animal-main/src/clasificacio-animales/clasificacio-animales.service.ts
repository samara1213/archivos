import { Injectable, InternalServerErrorException, Logger, BadRequestException } from '@nestjs/common';
import { CreateClasificacioAnimaleDto } from './dto/create-clasificacio-animale.dto';
import { UpdateClasificacioAnimaleDto } from './dto/update-clasificacio-animale.dto';
import { ClasificacioAnimal } from './entities/clasificacio-animale.entity';
import { Repository } from 'typeorm';
import { InjectRepository } from '@nestjs/typeorm';

@Injectable()
export class ClasificacioAnimalesService {

  // manejo de los log
  private readonly logger = new Logger('controlAnimalService');

  constructor(
    @InjectRepository(ClasificacioAnimal)
    private readonly clasificacionAnimalRepository: Repository<ClasificacioAnimal>,
  ){}

  async create(createClasificacioAnimaleDto: CreateClasificacioAnimaleDto) {
    
    try {

      // se crea el objecto a guarad en la base de datos
      const clasificacioAnimale = this.clasificacionAnimalRepository.create(createClasificacioAnimaleDto);

      // se guarda el registro en la base de datos
      await this.clasificacionAnimalRepository.save(clasificacioAnimale);

      // se regresa la clasificacion guardada
      return clasificacioAnimale;      
      
    } catch (error) {
      
      this.handleExceptions(error);
    }
  }

  async findAll() {
    
    try {

      // se regresan todas las clasificaciones de animales
      return await this.clasificacionAnimalRepository.find();      

    } catch (error) {
      
      this.handleExceptions(error);
    }
  }

  async findOne(id: string) {
    
    try {

      // busca en la base de datos el registro
      const clasificacioAnimale = await this.clasificacionAnimalRepository.findOneBy({
        id_clas: id,
      });

      if(!clasificacioAnimale) {

        throw new BadRequestException('La clasificacion no existe');
      }

      return clasificacioAnimale;
      
    } catch (error) {

      this.handleExceptions(error);
      
    }
  }

  async update(id: string, updateClasificacioAnimaleDto: UpdateClasificacioAnimaleDto) {
    
    // se obtine la informacion d ela clasificacion a actualizar y se precarga la data

    const clasificacioAnimale = await this.clasificacionAnimalRepository.preload({
      id_clas: id,
      ...updateClasificacioAnimaleDto,
    })

    // verifico si la empresa existe
    if (!clasificacioAnimale) {

      throw new BadRequestException('la Clasificacion a actualizar no existe');
    }

    try {

      // se busca la clasificacion en la base de datos
      this.clasificacionAnimalRepository.save(clasificacioAnimale);

      return clasificacioAnimale;      
      
    } catch (error) {
      
      this.handleExceptions(error);
    }
  }


  /**
   * Metodo que se encarga de validar cualquier  tipo de error 
   * @param error generado
   */
  private handleExceptions(error: any) {

    this.logger.error(error);
    // aca se ueden validar los codigos de error 
    throw new InternalServerErrorException('Error del sistema');
  }
}
