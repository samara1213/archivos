import { Controller, Get, Post, Body, Patch, Param, Delete, ParseUUIDPipe } from '@nestjs/common';
import { ClasificacioAnimalesService } from './clasificacio-animales.service';
import { CreateClasificacioAnimaleDto } from './dto/create-clasificacio-animale.dto';
import { UpdateClasificacioAnimaleDto } from './dto/update-clasificacio-animale.dto';

@Controller('clasificacio-animales')
export class ClasificacioAnimalesController {
  
  constructor(private readonly clasificacioAnimalesService: ClasificacioAnimalesService) {}

  @Post()
  create(@Body() createClasificacioAnimaleDto: CreateClasificacioAnimaleDto) {
    return this.clasificacioAnimalesService.create(createClasificacioAnimaleDto);
  }

  @Get()
  findAll() {
    return this.clasificacioAnimalesService.findAll();
  }

  @Get(':id')
  findOne(@Param('id', ParseUUIDPipe) id: string) {
    return this.clasificacioAnimalesService.findOne(id);
  }

  @Patch(':id')
  update(@Param('id', ParseUUIDPipe) id: string, @Body() updateClasificacioAnimaleDto: UpdateClasificacioAnimaleDto) {
    return this.clasificacioAnimalesService.update(id, updateClasificacioAnimaleDto);
  }

}
