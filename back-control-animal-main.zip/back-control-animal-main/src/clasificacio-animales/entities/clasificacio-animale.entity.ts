import { TipoVacuna } from "../../tipo-vacunas/entities/tipo-vacuna.entity";
import { Raza } from "../../razas/entities/raza.entity";
import { Column, CreateDateColumn, Entity, OneToMany, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";
import { Animal } from "src/animales/entities/animale.entity";

@Entity()
export class ClasificacioAnimal {

    @PrimaryGeneratedColumn('uuid')
    id_clas: string;

    @Column('text')
    nombre_clas: string;

    @CreateDateColumn({type: 'timestamp'})
    creacion_clas: Date;

    @UpdateDateColumn({type: 'timestamp'})
    modificacion_clas: Date;

    @OneToMany(
        () => Raza,
        (raza) => raza.clasificacionAnimal,
    )
    raza: Raza;

    @OneToMany(
        () => TipoVacuna,
        (tipoVacuna) => tipoVacuna.clasificacionAnimal,
    )
    tipoVacuna: TipoVacuna;

    @OneToMany(
        () => Animal,
        ( animal ) => animal.clasificacionAnimal,
    )
    animal: Animal;
}
