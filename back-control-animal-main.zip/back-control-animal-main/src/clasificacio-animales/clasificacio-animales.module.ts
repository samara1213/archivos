import { Module } from '@nestjs/common';
import { ClasificacioAnimalesService } from './clasificacio-animales.service';
import { ClasificacioAnimalesController } from './clasificacio-animales.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { ClasificacioAnimal } from './entities/clasificacio-animale.entity';

@Module({
  controllers: [ClasificacioAnimalesController],
  providers: [ClasificacioAnimalesService],
  imports: [TypeOrmModule.forFeature([ClasificacioAnimal]),  
  ],

  exports: [TypeOrmModule, ClasificacioAnimalesService]
})
export class ClasificacioAnimalesModule {}
