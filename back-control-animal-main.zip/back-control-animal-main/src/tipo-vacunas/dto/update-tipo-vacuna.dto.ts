import { PartialType } from '@nestjs/mapped-types';
import { CreateTipoVacunaDto } from './create-tipo-vacuna.dto';

export class UpdateTipoVacunaDto extends PartialType(CreateTipoVacunaDto) {}
