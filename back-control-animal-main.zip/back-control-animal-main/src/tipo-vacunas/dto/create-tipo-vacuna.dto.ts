import { IsString, IsUUID, MaxLength, MinLength } from "class-validator";

export class CreateTipoVacunaDto {

    @IsString()
    @MinLength(1)
    @MaxLength(20)
    nombre_tiva: string;

    @IsUUID()
    id_clasificacion_animal: string;
}
