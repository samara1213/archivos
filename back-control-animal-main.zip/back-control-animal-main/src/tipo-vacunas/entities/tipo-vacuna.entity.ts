import { ClasificacioAnimal } from "../../clasificacio-animales/entities/clasificacio-animale.entity";
import { Column, CreateDateColumn, Entity, ManyToOne, PrimaryGeneratedColumn, UpdateDateColumn } from "typeorm";

@Entity()
export class TipoVacuna {

    @PrimaryGeneratedColumn('uuid')
    id_tiva: string;

    @Column('text')
    nombre_tiva: string;

    @CreateDateColumn({type: 'timestamp'})
    creacion_tiva: Date;

    @UpdateDateColumn({type: 'timestamp'})
    modificacion_tiva: Date;

    @ManyToOne(
        () => ClasificacioAnimal,
        ( clasificacionAnimal ) => clasificacionAnimal.tipoVacuna,
        { eager: true},
    )
    clasificacionAnimal: ClasificacioAnimal;
}
