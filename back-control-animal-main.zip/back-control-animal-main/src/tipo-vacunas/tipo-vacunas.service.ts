import { BadRequestException, Injectable, InternalServerErrorException, Logger } from '@nestjs/common';
import { CreateTipoVacunaDto } from './dto/create-tipo-vacuna.dto';
import { UpdateTipoVacunaDto } from './dto/update-tipo-vacuna.dto';
import { Repository } from 'typeorm';
import { TipoVacuna } from './entities/tipo-vacuna.entity';
import { InjectRepository } from '@nestjs/typeorm';
import { ClasificacioAnimalesService } from '../clasificacio-animales/clasificacio-animales.service';

@Injectable()
export class TipoVacunasService {

  // manejo de los log
  private readonly logger = new Logger('RazaService');

  constructor(

    @InjectRepository(TipoVacuna)
    private  readonly tipoVacunaRepository: Repository<TipoVacuna>,

    private readonly clasificacionAnimalService: ClasificacioAnimalesService,
  )
  {}
  
  async create(createTipoVacunaDto: CreateTipoVacunaDto) {
    
    try {

      const {id_clasificacion_animal, ...restoTipoVacuna} = createTipoVacunaDto;

      // prepara el objecto a insertar
      let tipoVacuna = this.tipoVacunaRepository.create(restoTipoVacuna);

      const clasificacionAnimal = await this.clasificacionAnimalService.findOne(id_clasificacion_animal);

      tipoVacuna.clasificacionAnimal = clasificacionAnimal;

      await this.tipoVacunaRepository.save(tipoVacuna);

      return tipoVacuna;

      
    } catch (error) {
      
      this.handleExceptions(error);
    }
  }

  async findAll() {
    
    try {

      return this.tipoVacunaRepository.find(); 
      
    } catch (error) {
      
      this.handleExceptions(error);
    }
  }

  async findOne(id: string) {
    
    try {

      // buscamos el registro en la base de datos
      const tipoVacuna = await this.tipoVacunaRepository.findOneBy({
        id_tiva: id,
      });

      if(!tipoVacuna) throw new BadRequestException('No existe tipo de vacuna para este id');

      return tipoVacuna;
      
    } catch (error) {
      
      this.handleExceptions(error);
    }
  }

  async update(id: string, updateTipoVacunaDto: UpdateTipoVacunaDto) {
    
    try {

      // cargamos la informacion que se encuntra en la base de datos y agregamos los nue vos valores
      let tipoVacuna = await this.tipoVacunaRepository.preload({
        id_tiva: id,
        ...updateTipoVacunaDto,
      });

      if(!tipoVacuna) throw new BadRequestException('NO exite el tipo de vacuna a actualizar')
      
      // onbtnemos la informacion de la nueva clasificacion animal
      const clasificacionAnimal = await this.clasificacionAnimalService.findOne(updateTipoVacunaDto.id_clasificacion_animal);

     tipoVacuna.clasificacionAnimal = clasificacionAnimal

     await this.tipoVacunaRepository.save(tipoVacuna);

     return tipoVacuna;

    } catch (error) {
      
      this.handleExceptions(error);
    }
  }


  /**
   * Metodo que se encarga de validar cualquier  tipo de error 
   * @param error generado
   */
  private handleExceptions(error: any) {

    this.logger.error(error)
      // aca se ueden validar los codigos de error 
    throw new InternalServerErrorException('Error del sistema')
  }
}
