import { Module } from '@nestjs/common';
import { TipoVacunasService } from './tipo-vacunas.service';
import { TipoVacunasController } from './tipo-vacunas.controller';
import { TypeOrmModule } from '@nestjs/typeorm';
import { TipoVacuna } from './entities/tipo-vacuna.entity';
import { ClasificacioAnimalesModule } from 'src/clasificacio-animales/clasificacio-animales.module';

@Module({
  controllers: [TipoVacunasController],
  providers: [TipoVacunasService],
  imports: [TypeOrmModule.forFeature([TipoVacuna]),
    ClasificacioAnimalesModule,
  ],
  exports: [
   TypeOrmModule
  ]
})
export class TipoVacunasModule {}
