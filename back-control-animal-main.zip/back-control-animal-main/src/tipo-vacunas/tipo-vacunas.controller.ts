import { Controller, Get, Post, Body, Patch, Param, Delete, ParseUUIDPipe } from '@nestjs/common';
import { TipoVacunasService } from './tipo-vacunas.service';
import { CreateTipoVacunaDto } from './dto/create-tipo-vacuna.dto';
import { UpdateTipoVacunaDto } from './dto/update-tipo-vacuna.dto';

@Controller('tipo-vacunas')
export class TipoVacunasController {
  constructor(private readonly tipoVacunasService: TipoVacunasService) {}

  @Post()
  create(@Body() createTipoVacunaDto: CreateTipoVacunaDto) {
    return this.tipoVacunasService.create(createTipoVacunaDto);
  }

  @Get()
  findAll() {
    return this.tipoVacunasService.findAll();
  }

  @Get(':id')
  findOne(@Param('id', ParseUUIDPipe) id: string) {
    return this.tipoVacunasService.findOne(id);
  }

  @Patch(':id')
  update(@Param('id', ParseUUIDPipe) id: string, @Body() updateTipoVacunaDto: UpdateTipoVacunaDto) {
    return this.tipoVacunasService.update(id, updateTipoVacunaDto);
  }
  
}
