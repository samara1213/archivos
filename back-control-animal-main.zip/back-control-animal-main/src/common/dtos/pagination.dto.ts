import { Type } from "class-transformer";
import { IsNumber, IsOptional, IsPositive } from "class-validator";

export class PaginationDto {

    @IsOptional() 
    @IsPositive()
    @Type(() => Number) // esta anotacion se hace para combertir un campo que viene el query de la url que llaga como strig
    limit?: number;

    @IsOptional()    
    @Type(() => Number)
    offset?: number;
}