export class Seed {}
