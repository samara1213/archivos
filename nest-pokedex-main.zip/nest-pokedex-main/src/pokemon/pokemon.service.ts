import { Injectable, BadRequestException, InternalServerErrorException} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { ConfigService} from '@nestjs/config';
import { isValidObjectId, Model } from 'mongoose';
import { PaginationDto } from 'src/common/dto/pagination.dto';
import { CreatePokemonDto } from './dto/create-pokemon.dto';
import { UpdatePokemonDto } from './dto/update-pokemon.dto';
import { Pokemon } from './entities/pokemon.entity';

@Injectable()
export class PokemonService {

  constructor(

    @InjectModel( Pokemon.name)
    private readonly pokemonModel: Model<Pokemon>,
    private readonly configService: ConfigService,

  ){}
  
  async create(createPokemonDto: CreatePokemonDto) {

    createPokemonDto.name = createPokemonDto.name.toLocaleLowerCase();
    
    try {
      
      const pokemo = await this.pokemonModel.create(createPokemonDto);      
      return pokemo;

    } catch (error) {

      console.log(error);
      
      this.exeption(error);      
    }

   

  }

  findAll(paginationDto: PaginationDto) {

    const {limite = 10, offset = 0} = paginationDto
    return this.pokemonModel.find()
                            .limit(limite)
                            .skip(offset);

  }

  async findOne(term: string) {
    
    try {
      let pokemon : Pokemon;

      //validamos si es un munero 
      if(!isNaN(+term)) {

        pokemon = await this.pokemonModel.findOne({no:term});
      }
      
      //validamos si el termino es un id de mogo valido
      if(!pokemon && isValidObjectId(term)) {

        pokemon = await this.pokemonModel.findById(term);
      } 
      //validamos si loq ue tiene el termino es el nombre del poikemon
      if(!pokemon ) {
        pokemon = await this.pokemonModel.findOne({name:term.toLowerCase()});
      }
    
      
      //validamos si existe el pokem 
      if (!pokemon) throw new BadRequestException('No existe informacion que coicida');
    
    } catch (error) {
      
    }
    let pokemon: Pokemon;

    //validamos si el id es un numero

    return pokemon;
  }

  async update(term: string, updatePokemonDto: UpdatePokemonDto) {
    
    try {

      const pokemon = await this.findOne(term);
      if(updatePokemonDto.name){
        updatePokemonDto.name = updatePokemonDto.name.toLocaleLowerCase();
      }

      pokemon.updateOne(updatePokemonDto, {new: true}); // se coloca new: true para regresar el nuevo objecto

      return {...pokemon.toJSON(), ...updatePokemonDto};
      
    } catch (error) {

      console.log(error);

      this.exeption(error);
    }
  }

  async remove(id: string) {

    const pokemon = await this.findOne(id);

    //await pokemon.deleteOne();// 1 forma de eliminar

    // const result = await this.pokemonModel.findByIdAndDelete(id); // 2 forma de eliminat
    const {deletedCount} = await this.pokemonModel.deleteOne({_id: id});

    if(deletedCount ===0)
      throw new BadRequestException('no se encontro el dato a eliminar');
      
    return 'datos elimanos ';
    
  }

  private exeption(error :any) {

    if (error.code === 11000) {

      throw new BadRequestException('el pokemon ya existe');
    }
    throw new InternalServerErrorException('error al crear el pokemon ')
    
  }
}
