
//const { argv } = require('process');
const { options } = require('yargs');
const {crearTabla} = require('./helpers/multiplicar');
const argv = require('./config/yargs');


console.clear();
//const base = 5;

// este sirve para capturar desde la consulo
// const [ , , arg3 = 'base=5'] =process.argv;

// const [ , base = 5] = arg3.split('=');

// console.log(arg3)


crearTabla(argv.b, argv.listar, argv.h)
.then(nombre => console.log(nombre,'creado'))
.catch(err => console.log(err));

//para utilizar los yargs

console.log('la base de yargs es : ', argv.base);
