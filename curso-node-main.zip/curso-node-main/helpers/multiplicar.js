const fs = require('fs');
const colors = require('colors');




const crearTabla = async(base = 5, listar = false, hasta = 10) => {

    try {
        console.log(colors.green("##########################"))
        console.log("tabla del 5")
        console.log("##########################")       
    
        let salida = '';
        for (let a = 0; a <= hasta; a++) {
    
            salida += `${base} X ${a} = ${base * a} \n`;
        }
    
    
    
        // para crear un archivo 
        // fs.writeFile('tbla_del_5.txt', salida, (err) => {    
        //   if (err) throw err;
        //   console.log('tabla creada');
        // });
        fs.writeFileSync('tbla_del_3.txt', salida);
        if(listar) {
            
            console.log(salida);
        }

    
        return 'tabla creada';
        
    } catch (error) {
        
        return error;
    }

}

/// de esta manera de exporta las clases para ser utilizadas en otra case

module.exports = {
   crearTabla
}