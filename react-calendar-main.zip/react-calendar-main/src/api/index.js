
// este exportacion se hace de esta manera ya que se esta utilizando la exportacion por defecto
export { default as calendarApi} from './calendarApi';