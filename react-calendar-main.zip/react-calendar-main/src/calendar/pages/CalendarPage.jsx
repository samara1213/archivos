import { NavBar } from "../components/NavBar"
import { Calendar } from 'react-big-calendar'
import 'react-big-calendar/lib/css/react-big-calendar.css'

import { addHours } from 'date-fns'
import { getMessagesES, localizer } from '../../helpers'
import { CalendarEvent } from "../components/CalendarEvent"
import { useEffect, useState } from "react"
import { CalendarModal } from "../components/CalendarModal"
import { useUiStore,useCalendarStore, useAuthStore } from "../../hooks"
import { FabAddNew } from "../components/FabAddNew"
import { FabDeleteEvent } from "../components/FabDeleteEvent"



export const CalendarPage = () => {

const {user} = useAuthStore();
const {openDateModal} = useUiStore();
const { events, activeEvent,setActiveEvent,startLoadingEvent } = useCalendarStore();

const [lasView, setLasView] = useState(localStorage.getItem('lasView') || 'week')

  const eventStyleGetter = (event, start, end, isSelected) => {

    const isMyEvent = (user.uid === event.user._id) || (user.uid === event.user.uid);
    const style = {
      backgroundColor: isMyEvent? '#347CF7': '#465660',
      borderRadius: '0px',
      opacity: 0.8,
      color: 'white',

    }

    return {
      style
    }
  }

  const onDoubleClik = (event) => {

    openDateModal();
  }

  const onSelect = (event) => {

    setActiveEvent(event);
  }

  const onViewChanged = (event) => {

    localStorage.setItem('lasView', event);
  }

  useEffect(() => {
    startLoadingEvent();
  }, []);
  
  return (
    <>
      <NavBar />
      <div>
        <Calendar
          culture='es'
          localizer={localizer}
          events={events}
          defaultView={lasView}
          startAccessor="start"
          endAccessor="end"
          style={{ height: 500 }}
          messages={getMessagesES()}
          eventPropGetter={eventStyleGetter}
          components={{
            event: CalendarEvent,
          }
          }
          onDoubleClickEvent={onDoubleClik}
          onSelectEvent={onSelect}
          onView={onViewChanged}
        />
        <CalendarModal/>
        <FabAddNew/>
        <FabDeleteEvent/>
      </div>
    </>
  )
}
