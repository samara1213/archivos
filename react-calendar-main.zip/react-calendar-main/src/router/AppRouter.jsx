import { Navigate, Route, Routes } from "react-router-dom"
import { LoginPage } from "../auth/pages"
import { CalendarPage } from "../calendar/pages/CalendarPage"
import { useAuthStore } from "../hooks"
import { useEffect } from "react"


export const AppRouter = () => {
  

    const {status, checkAuthToken} = useAuthStore();

    useEffect(() => {

        checkAuthToken();
    }, []);

    if (status === 'checking') {

        return (
            <h1>Cargando...</h1>
        )
    }

  
    return (
    
    <Routes>
        {
            //Validamos si esta autenticado para ingresar a una de las dos paginas
            (status === 'not-authenticated') 
            ? (
                <>
                <Route path="/auth/*" element={ <LoginPage/>}></Route>
                <Route path="/*" element={ <Navigate to="/auth/login"/>}></Route>
                </>
            ) 
            : (
                <>
                <Route path="/" element={ <CalendarPage/>}></Route>
                <Route path="/*" element={ <Navigate to="/"/>}></Route>
                
                </>
            ) 
        }

        
        
        
    </Routes>
  )
}
