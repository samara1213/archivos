
import {useSelector,useDispatch} from 'react-redux';
import { calendarApi } from '../api';
import { clearErrorMessage, onChecking, onLogin, onLogout, onLogoutCalendar } from '../store';

export const useAuthStore = () => {

 const {status,user, errorMessage} = useSelector(state => state.auth);
 const dispatch = useDispatch();


 const startLogin = async({email,password}) => {

    try {

        //disparamos un estado de carga de la aplicacion
        dispatch(onChecking());

        //hacemos la peticion al baxkend
        // el /auth es el complete de la ruta ek {email,pasword} es el body
        const {data} = await calendarApi.post('/auth',{email,password});    
       
        //colocamos el token en el local storaje
        localStorage.setItem('token', data.token);

        dispatch(onLogin({name: data.name, uid: data.id}));
        
    } catch (error) {
       
        dispatch(onLogout('Credenciales incorrectas'));

        // esto es para que la siguiente accion se ejecute 10 milesimas de segundo despues
        setTimeout(() => {
           dispatch(clearErrorMessage()); 
        }, 10);
    }
 }

 const startRegister = async({email,password,name}) => {

    try {

        //disparamos un estado de carga de la aplicacion
        dispatch(onChecking());

        //hacemos la peticion al baxkend
        // el /auth es el complete de la ruta ek {email,pasword} es el body
        const {data} = await calendarApi.post('/auth/new',{email,password,name});

        //colocamos el token en el local storaje
        localStorage.setItem('token', data.token);

        dispatch(onLogin({name: data.name, uid: data.id}));
        
    } catch (error) {
       
        dispatch(onLogout(error.response.data?.msg || 'error interno'));
        // esto es para que la siguiente accion se ejecute 10 milesimas de segundo despues
        setTimeout(() => {
           dispatch(clearErrorMessage()); 
        }, 10);
    }


 }

 const checkAuthToken = async() => {

    const token = localStorage.getItem('token');

    if(!token) return dispatch(onLogout());

    try {
        const {data} = await calendarApi.get('/auth/reNew');

        //colocamos el token en el local storaje
        localStorage.setItem('token', data.token);

        dispatch(onLogin({name: data.name, uid: data.id}));

        
    } catch (error) {

        console.log(error);
        localStorage.clear();
        dispatch(onLogout());
        
    }
 }
 

 const startLogout = () => {

    localStorage.clear();
    dispatch(onLogoutCalendar());
    dispatch(onLogout());
 }
    return {
        status,
        user,
        errorMessage,
        startLogin,
        startRegister,
        checkAuthToken,
        startLogout,
    }
}