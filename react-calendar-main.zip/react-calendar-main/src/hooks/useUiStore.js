import { useDispatch, useSelector } from "react-redux"
import { onCloseDateModal, onOpenDateModal } from "../store";


export const useUiStore = () => {

 const  dispatch = useDispatch();

  const {
    isDateModalOpen
  } = useSelector(state => state.ui);

  const openDateModal = () => {
    // se llama la fucnion que abre el modal
    dispatch(onOpenDateModal());
  }

  const closeDateModal = () => {
    // se llama la fucnion que abre el modal
    dispatch(onCloseDateModal());
  }

  return {
    isDateModalOpen,
    openDateModal,
    closeDateModal,
  }
}